"""Glasshouse Tier 1 verification (headless — no Unreal required).

1. PARITY   — generate_plaza.rasterize() is bit-identical to the server's
              navigation.NavGrid on plaza.json AND on 200 fuzzed rect sets
              (random counts, positions, sub-cell edges, out-of-bounds,
              degenerate slivers). If these two ever diverge, agents clip
              through scenery; this test is the tripwire.
2. EXACT    — greedy meshing covers the solid set exactly: no clear cell
              under a wall box, no solid cell left unwalled, no overlaps.
3. STABLE   — identical inputs → identical boxes and lamp sites
              (deterministic regeneration; diffs in UE mean map diffs).
4. CLEAR    — every lamp site sits on a clear cell with a clear 3×3 margin.
"""
import json, random
import navigation as nav
import importlib.util, sys, pathlib
# import from the glasshouse dir without a package
spec = importlib.util.spec_from_file_location(
    "generate_plaza", pathlib.Path("glasshouse/generate_plaza.py"))
gp = importlib.util.module_from_spec(spec); spec.loader.exec_module(gp)
WORLD_SIZE, CELL = gp.WORLD_SIZE, gp.CELL

def server_grid(rects):
    g = nav.NavGrid(WORLD_SIZE, CELL)
    for r in rects:
        g.add_obstacle_rect(*r)
    return g.n, bytes(g._solid)

def check_parity(rects, label):
    n_s, solid_s = server_grid(rects)
    n_c, solid_c = gp.rasterize(rects)
    assert (n_s, bytes(solid_c)) == (n_s, solid_s), f"PARITY BREAK: {label}"
    boxes = gp.greedy_mesh(n_c, solid_c)
    rep = gp.parity_report(rects, boxes, n_c, solid_c)
    assert rep["coverage_exact"] and rep["overlaps"] == 0, (label, rep)
    return rep

# 1+2: the shipped map
plaza = json.load(open("deploy/maps/plaza.json"))
rep = check_parity(plaza, "plaza.json")
print(f"PASS plaza.json: {rep['solid_cells']} solid cells → "
      f"{rep['wall_boxes']} wall boxes, coverage exact vs live NavGrid")

# 1+2 fuzz: 200 hostile rect sets
rng = random.Random(7)
for trial in range(200):
    k = rng.randint(0, 9)
    rects = []
    for _ in range(k):
        x0 = rng.uniform(-20, 110); y0 = rng.uniform(-20, 110)
        rects.append([x0, y0,
                      x0 + rng.uniform(0.0, 45.0),      # incl. slivers
                      y0 + rng.uniform(0.0, 45.0)])
    check_parity(rects, f"fuzz#{trial}")
print("PASS fuzz: 200 random rect sets — client rasterizer bit-identical "
      "to server NavGrid, meshing exact on all")

# 3: determinism
n, solid = gp.rasterize(plaza)
assert gp.greedy_mesh(n, solid) == gp.greedy_mesh(n, bytearray(solid))
assert gp.lamp_sites(n, solid) == gp.lamp_sites(n, bytearray(solid))
print("PASS determinism: boxes and dressing identical across regenerations")

# 4: dressing clearance
sites = gp.lamp_sites(n, solid)
for wx, wy in sites:
    cx, cy = int(wx / CELL), int(wy / CELL)
    assert all(not solid[(cy+oy)*n + (cx+ox)]
               for oy in (-1,0,1) for ox in (-1,0,1)), (wx, wy)
print(f"PASS dressing: all {len(sites)} lamp sites clear with 3×3 margin")
print("\nALL GLASSHOUSE GENERATION TESTS PASSED")
