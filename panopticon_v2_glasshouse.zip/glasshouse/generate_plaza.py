"""
Project Panopticon — Glasshouse Tier 1: The Visual Town Scaffold
=================================================================
glasshouse/generate_plaza.py

Run INSIDE the Unreal Editor's Python environment (or via an MCP-connected
editor agent — see GLASSHOUSE_BUILD.md for the session runbook):

    py "glasshouse/generate_plaza.py" --map ../deploy/maps/plaza.json

Or headlessly (no `unreal` module) for a dry-run parity report:

    python3 generate_plaza.py --map ../deploy/maps/plaza.json --dry-run

THE THREE INVARIANTS, AS IMPLEMENTED
  1. THE JSON IS SACRED. plaza.json is the only input. Nothing here writes,
     annotates, or round-trips it. Regeneration is idempotent: every actor
     this script spawns carries the tag PANOPTICON_GENERATED and is deleted
     before a rebuild — hand-placed art is never touched.
  2. UNIDIRECTIONAL, VIA THE GRID. Geometry derives from the RASTERIZED
     grid, not the raw rectangles, because the server's collision pass
     operates on cells (navigation.NavGrid.solid_cell), not rects. The
     rasterizer below is a line-for-line mirror of NavGrid.add_obstacle_rect
     and is regression-tested against the real navigation.py for bit-exact
     parity (test_glasshouse_gen.py). Solid cells → merged wall boxes;
     clear cells → walkable street plane. A rect edge at x=16.4 becomes a
     wall face at x=17.0 — exactly where the server stops an agent.
  3. ZERO FEEDBACK. This script reads one JSON file and talks to one editor.
     It has no network client, no server import at runtime, no write path
     upstream. Decorative meshes spawn with CollisionProfile "NoCollision":
     client physics is presentation-only, and even ON the client nothing
     the dressing pass places can push a pawn — pawn transforms come from
     the wire, full stop.

FAIL-OPEN, AS ALWAYS
  The build has two tiers. STRUCTURE (ground, walls) must succeed or the
  script aborts loudly. DRESSING (lamps, props, PCG hookup) is wrapped in
  per-item guards: a missing asset or a deprecated API costs one log line
  and one absent lamp, never a failed build. A bare-walls plaza is a
  degraded plaza, not a broken one.
"""

from __future__ import annotations

import argparse
import json
import math
import random
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Constants — MUST agree with the frozen stack. Sources of truth cited.
# ---------------------------------------------------------------------------
WORLD_SIZE = 100.0        # EngineConfig.world_size (tick_engine.py)
CELL = 1.0                # NavGrid default cell_size (navigation.py)
WORLD_TO_UU = 100.0       # GLASSHOUSE_WORLD_TO_UU (MagnusObserver.h):
                          # 1 sim unit = 1 m = 100 Unreal units
WALL_HEIGHT_UU = 420.0    # presentation-only; no server meaning
GEN_TAG = "PANOPTICON_GENERATED"
GEN_FOLDER = "PanopticonPlaza"
DRESS_SEED = 1930         # deterministic dressing (from the release hash)


# ===========================================================================
# PURE LOGIC — no `unreal` import. Everything below this banner is
# headlessly testable, and test_glasshouse_gen.py proves grid parity
# against the server's actual navigation.NavGrid.
# ===========================================================================

def rasterize(rects: list[list[float]],
              world_size: float = WORLD_SIZE,
              cell: float = CELL) -> tuple[int, bytearray]:
    """LINE-FOR-LINE mirror of navigation.NavGrid.__init__ +
    add_obstacle_rect. Do not 'improve' this function: its value is
    being byte-identical in outcome to the server's rasterizer."""
    n = max(1, int(math.ceil(world_size / cell)))
    solid = bytearray(n * n)
    for x0, y0, x1, y1 in rects:
        cx0 = max(0, int(x0 / cell))
        cy0 = max(0, int(y0 / cell))
        cx1 = min(n - 1, int(x1 / cell))
        cy1 = min(n - 1, int(y1 / cell))
        for cy in range(cy0, cy1 + 1):
            base = cy * n
            for cx in range(cx0, cx1 + 1):
                solid[base + cx] = 1
    return n, solid


def greedy_mesh(n: int, solid: bytearray) -> list[tuple[int, int, int, int]]:
    """Merge solid cells into maximal axis-aligned boxes (cx0, cy0, cx1, cy1)
    inclusive. Classic greedy row-extend/column-grow: coverage is EXACT —
    the union of boxes equals the solid set, disjointly. Exactness is the
    invariant (asserted in tests); box count is merely nice."""
    consumed = bytearray(n * n)
    boxes: list[tuple[int, int, int, int]] = []
    for cy in range(n):
        for cx in range(n):
            i = cy * n + cx
            if not solid[i] or consumed[i]:
                continue
            # extend right
            cx1 = cx
            while cx1 + 1 < n and solid[cy * n + cx1 + 1] \
                    and not consumed[cy * n + cx1 + 1]:
                cx1 += 1
            # grow down while the full row span stays solid & unconsumed
            cy1 = cy
            while cy1 + 1 < n and all(
                    solid[(cy1 + 1) * n + x] and not consumed[(cy1 + 1) * n + x]
                    for x in range(cx, cx1 + 1)):
                cy1 += 1
            for yy in range(cy, cy1 + 1):
                for xx in range(cx, cx1 + 1):
                    consumed[yy * n + xx] = 1
            boxes.append((cx, cy, cx1, cy1))
    return boxes


def box_to_uu(box: tuple[int, int, int, int], cell: float = CELL
              ) -> tuple[float, float, float, float, float]:
    """(cx0,cy0,cx1,cy1) → UE (center_x_uu, center_y_uu, extent_x_uu,
    extent_y_uu, half_height_uu). Cell (cx,cy) spans world
    [cx*cell, (cx+1)*cell) — same convention as NavGrid.solid_at."""
    cx0, cy0, cx1, cy1 = box
    wx0, wy0 = cx0 * cell, cy0 * cell
    wx1, wy1 = (cx1 + 1) * cell, (cy1 + 1) * cell
    return ((wx0 + wx1) / 2 * WORLD_TO_UU,
            (wy0 + wy1) / 2 * WORLD_TO_UU,
            (wx1 - wx0) / 2 * WORLD_TO_UU,
            (wy1 - wy0) / 2 * WORLD_TO_UU,
            WALL_HEIGHT_UU / 2)


def lamp_sites(n: int, solid: bytearray, spacing_cells: int = 12,
               seed: int = DRESS_SEED) -> list[tuple[float, float]]:
    """Deterministic dressing sites: clear cells on a sparse lattice with a
    ≥1-cell clear margin (a lamp is thin, but the margin keeps them off
    wall faces where pawns brush past). Returns world coords."""
    rng = random.Random(seed)
    sites: list[tuple[float, float]] = []
    for cy in range(2, n - 2, spacing_cells):
        for cx in range(2, n - 2, spacing_cells):
            if any(solid[(cy + oy) * n + (cx + ox)]
                   for oy in (-1, 0, 1) for ox in (-1, 0, 1)):
                continue
            jx = rng.uniform(-0.3, 0.3)
            jy = rng.uniform(-0.3, 0.3)
            sites.append(((cx + 0.5 + jx) * CELL, (cy + 0.5 + jy) * CELL))
    return sites


def parity_report(rects: list[list[float]],
                  boxes: list[tuple[int, int, int, int]],
                  n: int, solid: bytearray) -> dict:
    """The audit habit: prove the meshed boxes reproduce the solid set
    EXACTLY before any of it becomes geometry."""
    covered = bytearray(n * n)
    overlap = 0
    for cx0, cy0, cx1, cy1 in boxes:
        for cy in range(cy0, cy1 + 1):
            for cx in range(cx0, cx1 + 1):
                i = cy * n + cx
                if covered[i]:
                    overlap += 1
                covered[i] = 1
    solid_count = sum(solid)
    exact = covered == solid and overlap == 0
    return {"rects": len(rects), "grid_n": n, "solid_cells": solid_count,
            "clear_cells": n * n - solid_count, "wall_boxes": len(boxes),
            "coverage_exact": exact, "overlaps": overlap}


def load_map(path: Path) -> list[list[float]]:
    rects = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(rects, list) or not all(
            isinstance(r, list) and len(r) == 4 for r in rects):
        raise ValueError(f"{path}: expected a JSON list of [x0,y0,x1,y1]")
    return rects


# ===========================================================================
# UNREAL SEAM — everything editor-facing lives below; imports are guarded so
# the pure logic above stays testable on any machine.
# ===========================================================================

CUBE = "/Engine/BasicShapes/Cube.Cube"
PLANE = "/Engine/BasicShapes/Plane.Plane"
CYLINDER = "/Engine/BasicShapes/Cylinder.Cylinder"


def build_in_editor(rects: list[list[float]]) -> None:
    import unreal  # only reachable inside the editor

    eas = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    n, solid = rasterize(rects)
    boxes = greedy_mesh(n, solid)
    report = parity_report(rects, boxes, n, solid)
    if not report["coverage_exact"]:
        raise RuntimeError(f"MESH PARITY FAILED — refusing to build: {report}")
    unreal.log(f"[panopticon] parity OK: {report}")

    # ---- idempotency: remove ONLY what we previously generated ------------
    stale = [a for a in eas.get_all_level_actors()
             if GEN_TAG in [str(t) for t in a.tags]]
    for a in stale:
        eas.destroy_actor(a)
    unreal.log(f"[panopticon] cleared {len(stale)} previously generated actors")

    def spawn(asset_path: str, loc, scale, label: str,
              collision: bool) -> "unreal.Actor":
        mesh = unreal.EditorAssetLibrary.load_asset(asset_path)
        actor = eas.spawn_actor_from_object(mesh, loc)
        actor.set_actor_scale3d(scale)
        actor.set_actor_label(label)
        actor.tags.append(unreal.Name(GEN_TAG))
        actor.set_folder_path(unreal.Name(GEN_FOLDER))
        if not collision:
            comp = actor.static_mesh_component
            comp.set_collision_profile_name(unreal.Name("NoCollision"))
        return actor

    # ---- STRUCTURE tier (must succeed) -------------------------------------
    half = WORLD_SIZE / 2 * WORLD_TO_UU
    # Ground: engine Plane is 100×100 uu at scale 1 → scale to world extents.
    spawn(PLANE, unreal.Vector(half, half, 0.0),
          unreal.Vector(WORLD_SIZE * WORLD_TO_UU / 100.0,
                        WORLD_SIZE * WORLD_TO_UU / 100.0, 1.0),
          "PLZ_Ground", collision=True)

    for i, box in enumerate(boxes):
        cx_uu, cy_uu, ex, ey, hz = box_to_uu(box)
        # Engine Cube is 100 uu; scale = full-size / 100.
        spawn(CUBE, unreal.Vector(cx_uu, cy_uu, hz),
              unreal.Vector(ex * 2 / 100.0, ey * 2 / 100.0, hz * 2 / 100.0),
              f"PLZ_Wall_{i:03d}", collision=True)
    unreal.log(f"[panopticon] STRUCTURE: ground + {len(boxes)} wall boxes")

    # ---- DRESSING tier (fail-open, per item) --------------------------------
    dressed, dropped = 0, 0
    for j, (wx, wy) in enumerate(lamp_sites(n, solid)):
        try:
            spawn(CYLINDER,
                  unreal.Vector(wx * WORLD_TO_UU, wy * WORLD_TO_UU, 150.0),
                  unreal.Vector(0.10, 0.10, 3.0),
                  f"PLZ_Lamp_{j:03d}", collision=False)   # presentation-only
            dressed += 1
        except Exception as exc:                     # noqa: BLE001 — fail-open
            dropped += 1
            unreal.log_warning(f"[panopticon] lamp {j} skipped: {exc}")
    unreal.log(f"[panopticon] DRESSING: {dressed} lamps ({dropped} dropped "
               f"fail-open)")

    # ---- POST-BUILD PARITY AUDIT -------------------------------------------
    # Every collidable generated actor's XY footprint must sit inside solid
    # cells; a violation means a future edit broke unidirectionality.
    violations = 0
    for a in eas.get_all_level_actors():
        tags = [str(t) for t in a.tags]
        if GEN_TAG not in tags or not str(a.get_actor_label()
                                          ).startswith("PLZ_Wall"):
            continue
        origin, extent = a.get_actor_bounds(only_colliding_components=True)
        x0 = (origin.x - extent.x) / WORLD_TO_UU + 1e-6
        y0 = (origin.y - extent.y) / WORLD_TO_UU + 1e-6
        x1 = (origin.x + extent.x) / WORLD_TO_UU - 1e-6
        y1 = (origin.y + extent.y) / WORLD_TO_UU - 1e-6
        for wy in (y0, y1):
            for wx in (x0, x1):
                cx = min(n - 1, max(0, int(wx / CELL)))
                cy = min(n - 1, max(0, int(wy / CELL)))
                if not solid[cy * n + cx]:
                    violations += 1
    if violations:
        unreal.log_error(f"[panopticon] PARITY AUDIT FAILED: {violations} "
                         f"wall corners over clear cells — geometry disagrees "
                         f"with the server collision pass")
    else:
        unreal.log(f"[panopticon] PARITY AUDIT PASS: every wall corner sits "
                   f"on a server-solid cell. The scenery cannot lie.")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--map", default="../deploy/maps/plaza.json")
    ap.add_argument("--dry-run", action="store_true")
    args, _unknown = ap.parse_known_args()   # UE injects its own argv noise

    rects = load_map(Path(args.map))
    n, solid = rasterize(rects)
    boxes = greedy_mesh(n, solid)
    report = parity_report(rects, boxes, n, solid)
    print(f"[panopticon] {report}")
    if not report["coverage_exact"]:
        print("[panopticon] MESH PARITY FAILED — aborting")
        return 1

    try:
        import unreal  # noqa: F401
        in_editor = True
    except ImportError:
        in_editor = False

    if args.dry_run or not in_editor:
        print(f"[panopticon] dry run: {len(boxes)} wall boxes, "
              f"{len(lamp_sites(n, solid))} lamp sites — no editor detected"
              if not in_editor else "[panopticon] dry run requested")
        return 0
    build_in_editor(rects)
    return 0


if __name__ == "__main__":
    sys.exit(main())
