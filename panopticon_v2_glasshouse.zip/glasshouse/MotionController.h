// ============================================================================
// Project Panopticon — Glasshouse Tier 2: The Motion Translation Layer
// glasshouse/MotionController.h
//
// Sits BETWEEN the Hermite interpolation and the pawn's skeleton. The chain
// of authority, in stone:
//
//   wire (20 Hz) ──► FAgentChannel ──► EvalHermite ──► ACTOR TRANSFORM
//                                          │              (server truth,
//                                          │               untouchable)
//                                          ▼
//                                   FPawnMotionFeatures        (this layer)
//                                          │  30 Hz, batched, UDP
//                                          ▼
//                                   motion_sidecar.py  (local GPU, own proc)
//                                          │  poses, latest-wins
//                                          ▼
//                                   COMPONENT-SPACE SKELETON
//                                   (root LOCKED, stride-warped)
//
// THE THREE INVARIANTS, AS CODE
//  1. ZERO WIRE CHANGES — conditioning is DERIVED: speed/heading/turn/accel
//     from consecutive Hermite tangents; locomotion state from speed with
//     hysteresis; gestures from entity-plane deltas the client already
//     decodes (owner changes, lock flips, cosign completions). Nothing new
//     crosses the server wire; the server does not know this layer exists.
//  2. FAIL-OPEN — the sidecar is a separate OS process. Watchdog: if no
//     fresh pose within PoseDeadlineMs, per-pawn blend alpha ramps to 0 and
//     the pawn is EXACTLY the Tier-1 capsule-glide — the fallback is the
//     absence of this layer, not a second system. Circuit breaker with
//     cooldown governs sidecar retries. No frame of world state is ever
//     gated on inference: pose apply is "latest completed or nothing."
//  3. PRESENTATION ONLY — ApplyPose() writes bone transforms in COMPONENT
//     space with root translation stripped (see the .cpp: the one function
//     where this invariant lives). The actor's world transform is written
//     by EvalHermite alone, before this layer runs, every frame.
//
// LOCAL IPC WIRE (localhost UDP, little-endian, packed — mirrored in
// motion_sidecar.py; static_asserts below are the compile-time handshake,
// exactly as the Phase 6 broadcaster wire):
//   REQUEST  header : uint32 seq | uint16 pawn_count | float dt      (10 B)
//   REQUEST  pawn   : char[8] id | float speed | float heading |
//                     float turn_rate | float accel |
//                     uint8 locomotion | uint8 gesture | uint8 flags |
//                     uint8 reserved                                 (28 B)
//   RESPONSE header : uint32 seq | uint16 pawn_count | uint8 status |
//                     uint8 reserved                                  (8 B)
//   RESPONSE pawn   : char[8] id | uint16 n_floats | float[n_floats]
//   Unreliable + seq-monotonic on both ends: stale responses dropped, stale
//   requests coalesced. Model-defined pose layout (n_floats) keeps this
//   contract model-agnostic: MotionBricks-class today, anything tomorrow.
// ============================================================================

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "MotionController.generated.h"

#pragma pack(push, 1)
struct FMotionRequestHeader
{
    uint32 Seq;
    uint16 PawnCount;
    float  Dt;
};
struct FMotionRequestPawn
{
    char   AgentId[8];       // the wire-plane compacted id — one namespace
    float  Speed;            // units/s, from Hermite tangents
    float  HeadingRad;
    float  TurnRateRadS;
    float  AccelUnitsS2;
    uint8  Locomotion;       // ELocomotionState
    uint8  Gesture;          // EGestureIntent
    uint8  Flags;            // bit0 speaking, bit1 degraded (wire flags)
    uint8  Reserved;
};
struct FMotionResponseHeader
{
    uint32 Seq;
    uint16 PawnCount;
    uint8  Status;           // 0 OK, 1 sidecar-degraded (stub gait)
    uint8  Reserved;
};
#pragma pack(pop)

static_assert(sizeof(FMotionRequestHeader) == 10, "request header drifted");
static_assert(sizeof(FMotionRequestPawn)   == 28, "request pawn drifted");
static_assert(sizeof(FMotionResponseHeader) == 8, "response header drifted");

UENUM()
enum class ELocomotionState : uint8
{
    Idle = 0, Walk = 1, Run = 2, Arrive = 3      // Arrive: speed collapsing
};

UENUM()
enum class EGestureIntent : uint8
{
    None = 0,
    ReachPickup = 1,    // entity owner_id became this pawn
    HandGive    = 2,    // entity owner_id left this pawn → nearby pawn
    UseOperate  = 3,    // entity state changed with last_used_by == pawn
    CosignPress = 4,    // pawn listed in a fresh opened_by
    Talk        = 5,    // FLAG_SPEAKING with no overriding gesture
};

UENUM()
enum class EMotionHealth : uint8
{
    Warm,       // fresh poses arriving inside deadline → blend toward 1
    Degraded,   // poses stale/slow → blend toward 0, keep requesting
    Dead,       // circuit breaker open → pure capsule-glide, retry on timer
};

// A short-lived animation intent distilled from one entity-plane delta.
struct FGestureEvent
{
    EGestureIntent Intent = EGestureIntent::None;
    double         ExpiresAt = 0.0;   // TTL: a reach that never played is
                                      // dropped, never queued into absurdity
};

// Per-pawn conditioning, rebuilt every controller tick from channel state.
struct FPawnMotionFeatures
{
    FVector2f Velocity   = FVector2f::ZeroVector;
    float     Speed      = 0.f;
    float     HeadingRad = 0.f;
    float     TurnRate   = 0.f;
    float     Accel      = 0.f;
    ELocomotionState Locomotion = ELocomotionState::Idle;
    EGestureIntent   Gesture    = EGestureIntent::None;
    uint8            WireFlags  = 0;
};

// Double-buffered pose: worker thread writes Back, game thread swaps+reads.
struct FPawnPoseBuffer
{
    TArray<float> Front;              // consumed by ApplyPose
    TArray<float> Back;               // written by the receive thread
    double        FrontReceivedAt = 0.0;
    FThreadSafeBool BackDirty = false;
    float         BlendAlpha = 0.f;   // 0 = pure capsule-glide (Tier 1)
};

UCLASS(ClassGroup=(Panopticon), meta=(BlueprintSpawnableComponent))
class GLASSHOUSE_API UGlasshouseMotionController : public UActorComponent
{
    GENERATED_BODY()

public:
    UGlasshouseMotionController();

    // ---- Tuning (all presentation-side; nothing here reaches the server)
    UPROPERTY(EditAnywhere, Category="Motion|Sidecar")
    FString SidecarHost = TEXT("127.0.0.1");
    UPROPERTY(EditAnywhere, Category="Motion|Sidecar")
    int32 SidecarPort = 17555;
    UPROPERTY(EditAnywhere, Category="Motion|Sidecar")
    float RequestHz = 30.f;           // model rate; render interpolates
    UPROPERTY(EditAnywhere, Category="Motion|FailOpen")
    float PoseDeadlineMs = 100.f;     // 3 model frames; then Degraded
    UPROPERTY(EditAnywhere, Category="Motion|FailOpen")
    float BlendInPerS = 3.f;          // alpha ramps — never pops
    UPROPERTY(EditAnywhere, Category="Motion|FailOpen")
    float BlendOutPerS = 6.f;         // degrade FASTER than recover
    UPROPERTY(EditAnywhere, Category="Motion|FailOpen")
    int32 BreakerFailureLimit = 5;    // consecutive deadline misses →
    UPROPERTY(EditAnywhere, Category="Motion|FailOpen")
    float BreakerCooldownS = 10.f;    // → Dead, retry after cooldown
    UPROPERTY(EditAnywhere, Category="Motion|Gestures")
    float GestureTtlS = 1.2f;

    virtual void TickComponent(float DeltaTime, ELevelTick TickType,
                               FActorComponentTickFunction* Fn) override;
    virtual void BeginPlay() override;
    virtual void EndPlay(const EEndPlayReason::Type Reason) override;

    // ---- Called by AMagnusObserver ------------------------------------------
    // From the entity-plane decode path: one delta in → at most one gesture.
    void OnEntityDelta(const FString& EntityId, const FString& NewOwner,
                       const FString& PrevOwner,
                       const TMap<FString, FString>& StateChanges,
                       const TArray<FString>& OpenedBy);
    // From Tick, AFTER EvalHermite has set the actor transform:
    void DriveSkeleton(const FString& AgentId, class APanopticonPawn* Pawn,
                       const struct FAgentChannel& Channel, float DeltaTime);

    // ---- Telemetry (client-side; surfaces in stat panel + logs) ------------
    uint64 RequestsSent = 0, PosesApplied = 0, PosesStale = 0;
    uint64 DeadlineMisses = 0, BreakerTrips = 0, GesturesEmitted = 0;
    EMotionHealth Health = EMotionHealth::Dead;   // dead until proven warm

private:
    FPawnMotionFeatures ExtractFeatures(const FAgentChannel& Ch,
                                        const FString& AgentId, double Now);
    void SendBatchIfDue(double Now, float Dt);
    void PumpResponses();             // receive thread body (seq-monotonic)
    void UpdateHealth(double Now);    // watchdog + circuit breaker
    void ApplyPose(class APanopticonPawn* Pawn, FPawnPoseBuffer& Buf,
                   const FPawnMotionFeatures& F, float DeltaTime);

    TMap<FString, FPawnPoseBuffer>  Poses;
    TMap<FString, FGestureEvent>    Gestures;
    TMap<FString, float>            PrevHeading;   // for turn-rate derivation
    TMap<FString, float>            PrevSpeed;     // for accel + hysteresis
    TArray<FPawnMotionFeatures>     BatchScratch;  // reused; no per-tick alloc
    FSocket*                        Socket = nullptr;
    FRunnableThread*                RecvThread = nullptr;
    uint32                          Seq = 0;
    uint32                          LastAppliedSeq = 0;
    double                          LastSendAt = 0.0;
    double                          LastPoseAt = 0.0;
    int32                           ConsecutiveMisses = 0;
    double                          BreakerOpenedAt = 0.0;
};
