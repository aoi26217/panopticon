"""
Project Panopticon — Tier 4: The Stylized Broadcast Layer
==========================================================
glasshouse/cosmos_director.py

An observer-side process that conditions a Cosmos-3-Edge-class world model
on the AUTHORITATIVE state stream and publishes hallucinated "camera
footage" of the plaza — under two non-negotiable disciplines:

  THE HONEST FRAMING, ENFORCED IN CODE. This is a stylized broadcast layer,
  never the renderer. World models drift; the server simulation is the
  inviolable ground truth. So every generated clip is checked by the
  DRIFT GUARD: the backend must declare where it believes each agent is at
  its keyframes, and if any declared position strays more than
  --drift-limit world units from the authoritative wire positions, the
  clip is REJECTED and conditioning is RE-GROUNDED from truth. Drift is
  not smoothed over, not blended, not forgiven — a beautiful clip that
  lies about where an agent stood does not air.

  PROVENANCE FAILS CLOSED — the one deliberate inversion of the house
  philosophy. Simulation liveness fails OPEN (a dead subsystem degrades
  the plaza but never stops it). Publishing integrity fails CLOSED: a clip
  reaches the publish directory only after (1) the DRAMATIZATION tag is
  embedded, (2) the burn-in watermark step succeeds, and (3) the Synthetic
  Video Detector NIM both RESPONDS and scores the clip as detectably
  synthetic (score >= --min-synth-score). Detector down? Nothing
  publishes. Detector says our synthetic footage reads as authentic?
  Nothing publishes — footage that could pass as real camera truth is
  exactly the footage we must never release untagged. Every published
  clip ships with a .provenance.json sidecar: tag, scores, drift audit,
  SHA-256, conditioning tick range.

Purity is inherited from Tier 3: the LiveKit grant is minted subscribe-only
(can_publish=False, can_publish_data=False). Read-only by permission, not
by manners. All heavy SDK surfaces (Cosmos runtime, watermark encoder, NIM
client) are seams behind three-method protocols with testable stubs — the
Tier 2 pattern: the pipeline's logic is provable today; checkpoints slot in
tomorrow.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import logging
import shutil
import struct
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from broadcaster import (AGENT_FMT, AGENT_SIZE, DATA_TOPIC,   # noqa: E402
                         FLAG_SPEAKING, HEADER_FMT, HEADER_SIZE)
from entities import ENTITY_TOPIC, decode_entity_deltas       # noqa: E402

log = logging.getLogger("panopticon.cosmos")
DRAMATIZATION_TAG = "DRAMATIZATION — SIMULATED FOOTAGE — PANOPTICON"


# ---------------------------------------------------------------------------
# Conditioning: a window of authoritative truth, compact and replayable.
# ---------------------------------------------------------------------------

@dataclass
class ConditioningWindow:
    tick_start: int
    tick_end: int
    agents: dict[str, list[tuple[int, float, float, float, float, bool]]]
    entities: list[dict]
    camera: str

    def to_prompt_payload(self) -> dict:
        return {"ticks": [self.tick_start, self.tick_end],
                "camera": self.camera,
                "agents": {a: [{"t": t, "x": round(x, 2), "y": round(y, 2),
                                "speaking": s}
                               for t, x, y, _vx, _vy, s in traj]
                           for a, traj in self.agents.items()},
                "entities": self.entities}


@dataclass
class ClipResult:
    path: Path
    # backend's declared belief: {tick: {agent_id: (x, y)}} at its keyframes
    declared_positions: dict[int, dict[str, tuple[float, float]]]
    meta: dict = field(default_factory=dict)


class CosmosBackend:          # SDK SEAM — Cosmos 3 Edge runtime behind this
    def generate(self, window: ConditioningWindow, out_dir: Path
                 ) -> ClipResult: raise NotImplementedError


class WatermarkEncoder:       # SDK SEAM — burn-in overlay + C2PA metadata
    def apply(self, clip: Path, tag: str) -> Path:
        raise NotImplementedError


class SyntheticDetector:      # SDK SEAM — Synthetic Video Detector NIM
    def score(self, clip: Path) -> float:          # synthetic probability
        raise NotImplementedError


# --- stubs: the pipeline's Tier-0, exactly as StubGaitModel was ------------

class StubCosmos(CosmosBackend):
    """Echoes truth with configurable injected drift — exists so the drift
    guard can be tested with drift of a KNOWN size."""
    def __init__(self, inject_drift: float = 0.0) -> None:
        self.inject_drift = inject_drift

    def generate(self, window, out_dir):
        clip = out_dir / f"clip_{window.tick_start}_{window.tick_end}.bin"
        clip.write_bytes(b"STUBVIDEO" + json.dumps(
            window.to_prompt_payload()).encode())
        declared = {}
        for aid, traj in window.agents.items():
            t, x, y, *_ = traj[-1]
            declared.setdefault(t, {})[aid] = (x + self.inject_drift, y)
        return ClipResult(clip, declared, {"backend": "stub"})


class StubWatermark(WatermarkEncoder):
    def apply(self, clip, tag):
        data = clip.read_bytes()
        clip.write_bytes(data + b"\nTAG:" + tag.encode())
        return clip


class StubDetector(SyntheticDetector):
    def __init__(self, fixed: float | None = 0.97):
        self.fixed = fixed                        # None → simulate NIM down

    def score(self, clip):
        if self.fixed is None:
            raise ConnectionError("detector NIM unreachable")
        return self.fixed


def load_seam(spec: str | None, default):
    if not spec:
        return default
    mod, _, cls = spec.partition(":")
    return getattr(__import__(mod, fromlist=[cls]), cls)()


# ---------------------------------------------------------------------------
# The director
# ---------------------------------------------------------------------------

@dataclass
class DirectorStats:
    windows: int = 0
    clips_generated: int = 0
    clips_published: int = 0
    drift_rejects: int = 0
    regrounds: int = 0
    provenance_blocks: int = 0
    detector_failures: int = 0


class BroadcastDirector:
    def __init__(self, backend, watermark, detector, out_dir: Path,
                 window_ticks: int = 100, drift_limit: float = 1.5,
                 min_synth_score: float = 0.8, camera: str = "plaza_wide"):
        self.backend, self.watermark, self.detector = (backend, watermark,
                                                       detector)
        self.out_dir = out_dir
        self.stage_dir = out_dir / "_staging"      # nothing airs from here
        self.stage_dir.mkdir(parents=True, exist_ok=True)
        self.window_ticks = window_ticks
        self.drift_limit = drift_limit
        self.min_synth_score = min_synth_score
        self.camera = camera
        self.stats = DirectorStats()
        self._traj: dict[str, list] = {}
        self._entities: dict[str, dict] = {}
        self._truth: dict[int, dict[str, tuple[float, float]]] = {}
        self._window_start: int | None = None
        self.last_tick = -1

    # ---- ingress (same discipline as every observer) -----------------------
    def on_data(self, packet) -> None:
        try:
            topic = getattr(packet, "topic", "")
            if topic == DATA_TOPIC:
                self._on_state(bytes(packet.data))
            elif topic == ENTITY_TOPIC:
                _t, recs = decode_entity_deltas(bytes(packet.data))
                for r in recs:
                    self._entities[r["id"]] = r
        except Exception:
            log.exception("packet dropped (fail-open ingest)")

    def _on_state(self, data: bytes) -> None:
        if len(data) < HEADER_SIZE:
            return
        tick, count = struct.unpack_from(HEADER_FMT, data, 0)
        if len(data) != HEADER_SIZE + count * AGENT_SIZE \
                or tick <= self.last_tick:
            return
        self.last_tick = tick
        if self._window_start is None:
            self._window_start = tick
        truth_now: dict[str, tuple[float, float]] = {}
        off = HEADER_SIZE
        for _ in range(count):
            wid, x, y, vx, vy, flags = struct.unpack_from(AGENT_FMT, data, off)
            off += AGENT_SIZE
            aid = wid.rstrip(b"\x00").decode()
            self._traj.setdefault(aid, []).append(
                (tick, x, y, vx, vy, bool(flags & FLAG_SPEAKING)))
            truth_now[aid] = (x, y)
        self._truth[tick] = truth_now

    def window_ready(self) -> bool:
        return (self._window_start is not None
                and self.last_tick - self._window_start >= self.window_ticks)

    def cut_window(self) -> ConditioningWindow:
        w = ConditioningWindow(self._window_start, self.last_tick,
                               dict(self._traj),
                               list(self._entities.values()), self.camera)
        self.stats.windows += 1
        self._traj = {}
        self._window_start = None
        return w

    # ---- drift guard: truth is not negotiable ------------------------------
    def audit_drift(self, clip: ClipResult) -> tuple[bool, float]:
        worst = 0.0
        for tick, declared in clip.declared_positions.items():
            truth = self._truth.get(tick)
            if truth is None:
                continue
            for aid, (dx, dy) in declared.items():
                if aid in truth:
                    tx, ty = truth[aid]
                    worst = max(worst, ((dx - tx) ** 2
                                        + (dy - ty) ** 2) ** 0.5)
        return worst <= self.drift_limit, worst

    # ---- the pipeline: generate → drift → tag → verify → publish -----------
    def produce(self) -> Path | None:
        window = self.cut_window()
        clip = self.backend.generate(window, self.stage_dir)
        self.stats.clips_generated += 1

        ok, worst = self.audit_drift(clip)
        if not ok:
            self.stats.drift_rejects += 1
            self.stats.regrounds += 1              # next window re-grounds
            clip.path.unlink(missing_ok=True)      # from truth by design
            log.warning("clip rejected: drift %.2f > %.2f — re-grounding",
                        worst, self.drift_limit)
            return None

        # ---------------- PROVENANCE: FAILS CLOSED -------------------------
        try:
            tagged = self.watermark.apply(clip.path, DRAMATIZATION_TAG)
            if b"TAG:" not in tagged.read_bytes():          # verify, don't
                raise RuntimeError("tag not present after apply")   # trust
            score = self.detector.score(tagged)
        except Exception as exc:
            self.stats.provenance_blocks += 1
            if isinstance(exc, ConnectionError):
                self.stats.detector_failures += 1
            clip.path.unlink(missing_ok=True)
            log.error("clip BLOCKED (provenance fails closed): %s", exc)
            return None
        if score < self.min_synth_score:
            # Detectably-synthetic is a RELEASE REQUIREMENT: footage that
            # could pass as real camera truth must never leave staging.
            self.stats.provenance_blocks += 1
            clip.path.unlink(missing_ok=True)
            log.error("clip BLOCKED: synth score %.2f < %.2f — too "
                      "plausible to air", score, self.min_synth_score)
            return None

        final = self.out_dir / clip.path.name
        shutil.move(str(clip.path), final)
        digest = hashlib.sha256(final.read_bytes()).hexdigest()
        final.with_suffix(final.suffix + ".provenance.json").write_text(
            json.dumps({"tag": DRAMATIZATION_TAG,
                        "synthetic_score": score,
                        "drift_worst_units": round(worst, 3),
                        "drift_limit": self.drift_limit,
                        "ticks": [window.tick_start, window.tick_end],
                        "sha256": digest,
                        "backend": clip.meta}, indent=1))
        self.stats.clips_published += 1
        return final


async def amain(args) -> None:
    from livekit import api, rtc                  # deferred: stubs need no SFU
    director = BroadcastDirector(
        load_seam(args.backend, StubCosmos()),
        load_seam(args.watermark, StubWatermark()),
        load_seam(args.detector, StubDetector()),
        Path(args.out_dir), args.window_ticks, args.drift_limit,
        args.min_synth_score, args.camera)
    token = (api.AccessToken(args.livekit_api_key, args.livekit_api_secret)
             .with_identity("panopticon-cosmos-director")
             .with_grants(api.VideoGrants(
                 room_join=True, room=args.room, can_subscribe=True,
                 can_publish=False, can_publish_data=False))   # PURITY
             .to_jwt())
    room = rtc.Room()
    room.on("data_received", director.on_data)
    await room.connect(args.livekit_url, token)
    log.info("broadcast director up (read-only; provenance fails closed)")
    try:
        while True:
            await asyncio.sleep(0.5)
            if director.window_ready():
                await asyncio.get_running_loop().run_in_executor(
                    None, director.produce)        # Tier 2 lesson: heavy
            s = director.stats                     # work off the loop
            if s.windows and s.windows % 20 == 0:
                log.info("%s", s)
    finally:
        await room.disconnect()


def main() -> None:
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s COSMOS %(message)s")
    p = argparse.ArgumentParser(description="Panopticon broadcast director")
    p.add_argument("--livekit-url", required=True)
    p.add_argument("--livekit-api-key", required=True)
    p.add_argument("--livekit-api-secret", required=True)
    p.add_argument("--room", default="panopticon")
    p.add_argument("--out-dir", default="./broadcast")
    p.add_argument("--window-ticks", type=int, default=100)   # 5 s windows
    p.add_argument("--drift-limit", type=float, default=1.5)
    p.add_argument("--min-synth-score", type=float, default=0.8)
    p.add_argument("--camera", default="plaza_wide")
    p.add_argument("--backend", default=None, help="pkg.mod:Class seam")
    p.add_argument("--watermark", default=None, help="pkg.mod:Class seam")
    p.add_argument("--detector", default=None, help="pkg.mod:Class seam")
    asyncio.run(amain(p.parse_args()))


if __name__ == "__main__":
    main()
