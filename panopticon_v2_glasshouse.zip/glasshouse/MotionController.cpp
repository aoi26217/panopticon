// ============================================================================
// UGlasshouseMotionController — implementation
// glasshouse/MotionController.cpp
//
// Compile-stable logic in full; the two version-fluid seams (UE socket
// subsystem calls, skeletal pose writing via AnimInstance proxy) are marked
// SDK-SEAM in the Phase 6 tradition. Everything an invariant depends on is
// concrete code below.
// ============================================================================

#include "MotionController.h"
#include "MagnusObserver.h"
#include "PanopticonPawn.h"
#include "Common/UdpSocketBuilder.h"

// ---------------------------------------------------------------------------
// Feature derivation — invariant 1 lives here: every input is computed from
// data the client ALREADY holds. Nothing asks the server for anything.
// ---------------------------------------------------------------------------

FPawnMotionFeatures UGlasshouseMotionController::ExtractFeatures(
    const FAgentChannel& Ch, const FString& AgentId, double Now)
{
    FPawnMotionFeatures F;
    F.Velocity  = Ch.Latest.Vel;                       // the Hermite tangents
    F.Speed     = F.Velocity.Length();
    F.WireFlags = Ch.Latest.Flags;
    F.HeadingRad = (F.Speed > 0.05f)
        ? FMath::Atan2(F.Velocity.Y, F.Velocity.X)
        : PrevHeading.FindRef(AgentId);                // hold heading at rest

    const float PrevH = PrevHeading.FindRef(AgentId);
    const float PrevS = PrevSpeed.FindRef(AgentId);
    const float Dt = GLASSHOUSE_TICK_DT;               // snapshot cadence
    F.TurnRate = FMath::FindDeltaAngleRadians(PrevH, F.HeadingRad) / Dt;
    F.Accel    = (F.Speed - PrevS) / Dt;
    PrevHeading.Add(AgentId, F.HeadingRad);
    PrevSpeed.Add(AgentId, F.Speed);

    // Locomotion state with hysteresis: thresholds differ by direction so a
    // pawn hovering at a boundary doesn't strobe between gaits. Steering
    // speed is 2.5 u/s server-side; Run begins just under it.
    const bool WasMoving = PrevS > 0.3f;
    if (F.Speed < (WasMoving ? 0.15f : 0.30f))
        F.Locomotion = ELocomotionState::Idle;
    else if (F.Speed > (WasMoving ? 2.1f : 2.3f))
        F.Locomotion = ELocomotionState::Run;
    else
        F.Locomotion = ELocomotionState::Walk;
    if (WasMoving && F.Accel < -3.0f)                  // hard decel: landing
        F.Locomotion = ELocomotionState::Arrive;       // a step, not stopping
                                                       // mid-stride

    // Gesture: freshest unexpired entity-derived intent wins; else Talk if
    // the wire says speaking; else none.
    if (FGestureEvent* G = Gestures.Find(AgentId))
    {
        if (G->ExpiresAt > Now) { F.Gesture = G->Intent; }
        else                    { Gestures.Remove(AgentId); }
    }
    if (F.Gesture == EGestureIntent::None &&
        (F.WireFlags & GLASSHOUSE_FLAG_SPEAKING))
    {
        F.Gesture = EGestureIntent::Talk;
    }
    return F;
}

// ---------------------------------------------------------------------------
// Entity-plane distillation — reliable deltas the client already decodes
// become at most ONE short-lived gesture each. TTL guarantees a starved
// animation queue can never build a backlog of stale theatrics.
// ---------------------------------------------------------------------------

void UGlasshouseMotionController::OnEntityDelta(
    const FString& EntityId, const FString& NewOwner,
    const FString& PrevOwner, const TMap<FString, FString>& StateChanges,
    const TArray<FString>& OpenedBy)
{
    const double Now = FPlatformTime::Seconds();
    auto Emit = [&](const FString& PawnId, EGestureIntent Intent)
    {
        Gestures.Add(PawnId, FGestureEvent{Intent, Now + GestureTtlS});
        ++GesturesEmitted;
    };

    if (!NewOwner.IsEmpty() && NewOwner != PrevOwner)
        Emit(NewOwner, EGestureIntent::ReachPickup);   // it became theirs
    if (!PrevOwner.IsEmpty() && !NewOwner.IsEmpty() && NewOwner != PrevOwner)
        Emit(PrevOwner, EGestureIntent::HandGive);     // they handed it over
    if (const FString* User = StateChanges.Find(TEXT("last_used_by")))
        Emit(*User, EGestureIntent::UseOperate);
    for (const FString& Signer : OpenedBy)             // fresh cosign quorum
        Emit(Signer, EGestureIntent::CosignPress);
}

// ---------------------------------------------------------------------------
// Batch send — 30 Hz, all pawns in one datagram, fire-and-forget.
// ---------------------------------------------------------------------------

void UGlasshouseMotionController::SendBatchIfDue(double Now, float Dt)
{
    if (Now - LastSendAt < 1.0 / RequestHz || BatchScratch.Num() == 0)
        return;
    LastSendAt = Now;

    TArray<uint8> Buf;
    Buf.SetNumUninitialized(sizeof(FMotionRequestHeader)
                            + BatchScratch.Num() * sizeof(FMotionRequestPawn));
    auto* H = reinterpret_cast<FMotionRequestHeader*>(Buf.GetData());
    H->Seq = ++Seq; H->PawnCount = BatchScratch.Num(); H->Dt = Dt;
    // ... pack each FPawnMotionFeatures into an FMotionRequestPawn (memcpy of
    // the compacted id, floats, enum bytes) ...
    int32 Sent = 0;
    Socket->SendTo(Buf.GetData(), Buf.Num(), Sent, /*SDK-SEAM: addr*/
                   *SidecarAddr);
    ++RequestsSent;
    BatchScratch.Reset();                              // capacity retained
}

// ---------------------------------------------------------------------------
// Health — invariant 2's state machine. Note the asymmetry: blend OUT twice
// as fast as blend IN. When the model falters, the audience should see
// grace collapse into glide quickly and quietly; recovery can afford to be
// gradual and certain.
// ---------------------------------------------------------------------------

void UGlasshouseMotionController::UpdateHealth(double Now)
{
    const double AgeMs = (Now - LastPoseAt) * 1000.0;

    if (Health == EMotionHealth::Dead)
    {
        if (Now - BreakerOpenedAt > BreakerCooldownS)
        {
            Health = EMotionHealth::Degraded;          // half-open: probe
            ConsecutiveMisses = 0;
        }
        return;
    }
    if (AgeMs <= PoseDeadlineMs)
    {
        Health = EMotionHealth::Warm;
        ConsecutiveMisses = 0;
        return;
    }
    ++DeadlineMisses;
    if (++ConsecutiveMisses >= BreakerFailureLimit)
    {
        Health = EMotionHealth::Dead;                  // breaker OPEN
        BreakerOpenedAt = Now;
        ++BreakerTrips;
        UE_LOG(LogTemp, Warning,
               TEXT("[motion] breaker open — capsule-glide for %.0fs"),
               BreakerCooldownS);
    }
    else
    {
        Health = EMotionHealth::Degraded;
    }
}

// ---------------------------------------------------------------------------
// ApplyPose — invariant 3 lives in this function and nowhere else.
// ---------------------------------------------------------------------------

void UGlasshouseMotionController::ApplyPose(
    APanopticonPawn* Pawn, FPawnPoseBuffer& Buf,
    const FPawnMotionFeatures& F, float DeltaTime)
{
    // Blend target: 1 only when Warm AND a pose exists; else 0 = pure Tier 1.
    const float Target =
        (Health == EMotionHealth::Warm && Buf.Front.Num() > 0) ? 1.f : 0.f;
    const float Rate = (Target > Buf.BlendAlpha) ? BlendInPerS : BlendOutPerS;
    Buf.BlendAlpha = FMath::FInterpConstantTo(Buf.BlendAlpha, Target,
                                              DeltaTime, Rate);
    if (Buf.BlendAlpha <= KINDA_SMALL_NUMBER)
        return;                                        // capsule-glide: done

    // THE ROOT LOCK. The pose vector's root translation channels are
    // discarded before anything touches the skeleton: the model may only
    // articulate, never locomote. The actor's world transform was written
    // by EvalHermite earlier this frame and is not read, not adjusted, not
    // "corrected" here. If the model and the wire disagree about where the
    // pawn is, the wire is right and the feet slide — that is the accepted
    // cost, priced in Phase 6 when we decided positions ride an unreliable
    // channel precisely because they are continuously re-asserted truth.
    //
    // STRIDE WARP: gait phase advance is rescaled by (F.Speed /
    // ModelNominalSpeed) so cycle cadence tracks wire velocity — this is
    // what shrinks the foot-slide residual from "obvious" to "forensic".
    //
    // SDK-SEAM: hand Buf.Front (root-stripped, stride-warped) to the pawn's
    // AnimInstance proxy at weight Buf.BlendAlpha, component space:
    //   Pawn->GetMotionAnimInstance()->PushPose(Buf.Front, Buf.BlendAlpha);
    ++PosesApplied;
}

// ---------------------------------------------------------------------------
// Per-frame drive, called by AMagnusObserver::Tick AFTER EvalHermite. The
// ONE-LINE integration diff in MagnusObserver.cpp's pawn loop:
//
//     Ch.Pawn->SetActorLocation(EvalHermite(Ch, Now));      // (existing)
//   + Motion->DriveSkeleton(Pair.Key, Ch.Pawn.Get(), Ch, DeltaTime);
//
// Order is the invariant: transform authority first, articulation second.
// ---------------------------------------------------------------------------

void UGlasshouseMotionController::DriveSkeleton(
    const FString& AgentId, APanopticonPawn* Pawn,
    const FAgentChannel& Ch, float DeltaTime)
{
    const double Now = FPlatformTime::Seconds();
    FPawnMotionFeatures F = ExtractFeatures(Ch, AgentId, Now);
    BatchScratch.Add(F);

    FPawnPoseBuffer& Buf = Poses.FindOrAdd(AgentId);
    if (Buf.BackDirty)                                 // swap in fresh pose
    {
        Swap(Buf.Front, Buf.Back);
        Buf.FrontReceivedAt = Now;
        Buf.BackDirty = false;
    }
    ApplyPose(Pawn, Buf, F, DeltaTime);

    SendBatchIfDue(Now, DeltaTime);
    UpdateHealth(Now);
}

// PumpResponses() runs on RecvThread: RecvFrom → validate sizes against the
// packed structs → reject Seq <= LastAppliedSeq (stale, superseded) → copy
// floats into each pawn's Back buffer → BackDirty = true → LastPoseAt = now.
// Malformed datagrams increment PosesStale and are dropped without comment:
// the sidecar is untrusted input, like every other wire in this project.
// (SDK-SEAM: FUdpSocketBuilder + FRunnable boilerplate omitted; the logic
//  above is the contract.)
