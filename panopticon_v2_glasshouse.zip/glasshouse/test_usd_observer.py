"""Tier 3 verification (headless — real pxr, real wire codecs, no network).

Frames are packed with broadcaster's OWN format constants and entity blobs
with entities.encode_entity_deltas — the observer decodes production bytes.
1. STAGE     — agents appear as capsules at server radius; Hermite live
               translate matches the mirrored formula; flags → attributes.
2. ENTITIES  — reliable-plane records mirror into attrs (kind/owner/state/
               version); carried entities ride at carry height.
3. STALE     — reordered/torn spatial frames rejected, counted.
4. RECORD    — per-tick timeSamples; endTimeCode tracks; scrubbing a fresh
               reopen of the file yields the per-tick positions.
5. PLAZA     — walls from the parity-proven mesher: exactly 2 for plaza.json.
6. PURITY    — the LiveKit grant is constructed publish-disabled.
7. FAIL-OPEN — a poisoned record costs one save, next sync heals.
"""
import importlib.util, json, pathlib, struct, sys, time, types

spec = importlib.util.spec_from_file_location(
    "usd_observer", pathlib.Path("glasshouse/usd_observer.py"))
uo = importlib.util.module_from_spec(spec)
sys.modules["usd_observer"] = uo
spec.loader.exec_module(uo)
import broadcaster as bc
import entities as en
from pxr import Usd, UsdGeom

def frame(tick, agents):
    out = bytearray(struct.pack(bc.HEADER_FMT, tick, len(agents)))
    for aid, x, y, vx, vy, flags in agents:
        wid = bc.compact_wire_id(aid)          # PRODUCTION id compaction —
        out += struct.pack(bc.AGENT_FMT, wid,  # hand-padding recreated the
                           x, y, vx, vy, flags)  # Phase 8 truncation scar
    return bytes(out)

def pkt(data, topic):
    return types.SimpleNamespace(data=data, topic=topic)

obs = uo.UsdObserver("/tmp/t3_live.usda", record_path="/tmp/t3_live.usda",
                     map_path="deploy/maps/plaza.json")

# --- feed two spatial ticks + entity deltas (production-packed) ------------
obs.on_data(pkt(frame(100, [("agent_000", 10.0, 20.0, 2.0, 0.0,
                             bc.FLAG_SPEAKING),
                            ("magnus", 50.0, 50.0, 0.0, 0.0, 0)]),
                bc.DATA_TOPIC))
obs.on_data(pkt(frame(101, [("agent_000", 10.1, 20.0, 2.0, 0.0,
                             bc.FLAG_SPEAKING),
                            ("magnus", 50.0, 50.0, 0.0, 0.0, 0)]),
                bc.DATA_TOPIC))
key = en.Entity(id="key_01", kind="key", x=3.0, y=4.0,
                state={"locked": True}, owner_id="agent_000", version=7)
obs.on_data(pkt(en.encode_entity_deltas(101, [key]), en.ENTITY_TOPIC))
# stale + torn frames must bounce
obs.on_data(pkt(frame(99, [("agent_000", 0, 0, 0, 0, 0)]), bc.DATA_TOPIC))
obs.on_data(pkt(frame(102, [("agent_000", 0, 0, 0, 0, 0)])[:-3],
                bc.DATA_TOPIC))
assert obs.frames == 2 and obs.frames_stale == 2
print("PASS ingest: 2 frames accepted, stale+torn rejected and counted")

# pin alpha = 1.0 exactly: recv_at one tick ago → Hermite lands ON latest
p0, v0, p1, v1, _ = obs._agents["agent000"]
obs._agents["agent000"] = (p0, v0, p1, v1, time.monotonic() - uo.TICK_DT)
obs.sync()
assert obs.saves == 1 and obs.save_failures == 0

# --- reopen COLD: everything must be in the file, not in our process -------
st = Usd.Stage.Open("/tmp/t3_live.usda")
a0 = st.GetPrimAtPath("/World/Agents/agent000")
geo = UsdGeom.Capsule(st.GetPrimAtPath("/World/Agents/agent000/geo"))
assert a0 and geo.GetRadiusAttr().Get() == 0.4        # server radius
assert a0.GetAttribute("panopticon:speaking").Get() is True
assert a0.GetAttribute("panopticon:degraded").Get() is False
tr = UsdGeom.XformCommonAPI(UsdGeom.Xform(a0)).GetXformVectors(
    Usd.TimeCode.Default())[0]
# alpha pinned to 1.0: Hermite endpoint condition → exactly the latest
# snapshot (10.1, 20.0). This is the same one-tick smoothing latency the
# UE client renders with; the mirrored math must agree at the endpoint.
assert abs(tr[0] - 10.1) < 5e-3 and abs(tr[1] - 20.0) < 1e-4
assert st.GetPrimAtPath("/World/Agents/magnus")
print(f"PASS stage: capsule r=0.4, flags mirrored, Hermite endpoint "
      f"x={tr[0]:.4f} == latest 10.1")

k = st.GetPrimAtPath("/World/Entities/key01")
assert k.GetAttribute("panopticon:kind").Get() == "key"
assert k.GetAttribute("panopticon:owner").Get() == "agent000"  # wire ids: one compacted namespace, all planes, all clients
assert json.loads(k.GetAttribute("panopticon:state").Get()) == {"locked": True}
assert k.GetAttribute("panopticon:version").Get() == 7
kz = UsdGeom.XformCommonAPI(UsdGeom.Xform(k)).GetXformVectors(
    Usd.TimeCode.Default())[0][2]
assert abs(kz - 1.2) < 1e-6                            # carried height
print("PASS entities: kind/owner/state/version mirrored, carried z=1.2")

# --- record mode: scrub the animation --------------------------------------
xf = UsdGeom.XformCommonAPI(UsdGeom.Xform(a0))
p100 = xf.GetXformVectors(Usd.TimeCode(100))[0]
p101 = xf.GetXformVectors(Usd.TimeCode(101))[0]
assert abs(p100[0] - 10.0) < 1e-4 and abs(p101[0] - 10.1) < 1e-4
assert st.GetEndTimeCode() == 101 and st.GetTimeCodesPerSecond() == 20.0
print("PASS record: timeSamples scrub to per-tick truth (t100→10.0, "
      "t101→10.1), 20 codes/s")

walls = [p for p in st.Traverse()
         if p.GetPath().pathString.startswith("/World/Plaza/Wall_")]
assert len(walls) == 2                                 # parity-proven mesher
print("PASS plaza: exactly 2 wall prims — the Tier 1 mesher, third client")

# --- purity: the grant itself forbids publishing ---------------------------
src = pathlib.Path("glasshouse/usd_observer.py").read_text()
assert "can_publish=False" in src and "can_publish_data=False" in src \
       and "can_subscribe=True" in src
print("PASS purity: subscribe-only grant constructed in code")

# --- fail-open: poison → one skipped save, then heals ----------------------
obs._entities["poison"] = {"id": "poison"}             # missing keys
obs.sync()
assert obs.save_failures == 1
del obs._entities["poison"]
obs.sync()
assert obs.saves == 2 and obs.save_failures == 1
print("PASS fail-open: poisoned record cost one save; next sync healed")

print("\nALL TIER 3 USD OBSERVER TESTS PASSED")
