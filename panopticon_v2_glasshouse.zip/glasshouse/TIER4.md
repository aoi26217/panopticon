# Glasshouse Tier 4 — The Experimental Frontier

Architectural specification and runbook for the four Tier 4 workstreams.
Companion code: `artifixer_invert.py`, `cosmos_director.py` (+ their test
suites), `deploy/docker-compose-dgx.yml`. Read `README.md` §1–2 first; every
rule here is a consequence of an invariant defined there.

## 0. The Governing Asymmetry

Two failure philosophies coexist in this tier, and confusing them is the
only way to get hurt:

| Domain | Philosophy | Example |
|---|---|---|
| Simulation liveness | **FAIL OPEN** | Cosmos crashes → the plaza keeps living; UE5 and USD observers unaffected (SFU topology) |
| Published output | **FAIL CLOSED** | Detector NIM unreachable → the clip is destroyed in staging, never aired |

A dead subsystem may degrade the world. A dead safety check may not degrade
the truthfulness of what we publish about it.

## 1. Cosmos — The Stylized Broadcast Layer (`cosmos_director.py`)

**What it is:** an observer-side, subscribe-only process (Tier 3 purity:
`can_publish=False` in the LiveKit grant) that cuts the authoritative
stream into conditioning windows (default 100 ticks = 5 s), hands them to a
Cosmos-3-Edge-class backend, and shepherds the hallucinated footage through
two gates before anything reaches the publish directory.

**What it is not, enforced:** the renderer. World models drift, and the
DRIFT GUARD makes drift a rejection, not a footnote — the backend must
declare its believed agent positions at keyframes; any position more than
`--drift-limit` (1.5 world units — chosen: below it, disagreement hides
inside a character's body; above it, an agent visibly stands somewhere it
never stood) from wire truth destroys the clip and re-grounds the next
window from authoritative state. Verified: a 2.0-unit lie is rejected, a
1.0-unit stylization airs. Truth is a limit, not vanity.

**The provenance gate, in order, all mandatory:**
1. `DRAMATIZATION — SIMULATED FOOTAGE` embedded by the watermark seam —
   then **read back and verified** (a silently no-op watermark is caught;
   trust nothing that claims success).
2. Synthetic Video Detector NIM scores the clip. It must (a) respond and
   (b) score ≥ `--min-synth-score` (0.8). Detectably-synthetic is a
   **release requirement**: footage of our fake plaza that could pass as
   real camera truth is precisely what must never leave staging.
3. Publish + `.provenance.json` sidecar: tag, synthetic score, worst drift,
   tick range, SHA-256 — the same chain-of-custody discipline as the
   release zip, applied per clip.

All three SDK surfaces (Cosmos runtime, watermark/C2PA encoder, NIM
client) are `pkg.module:Class` seams with tested stubs — the pipeline's
logic is proven today (six-test suite, all green); checkpoints slot in
without touching gate code. Deploy the real seams via `--backend/--watermark/
--detector`; run detached from the show loop — clips are minutes-later
artifacts, never the live feed (that remains UE5/USD, rendering truth).

## 2. Newton — Cosmetic Physics (integration spec; runtime lives in Omniverse)

Newton simulates what the server rightly refuses to: rain, puddles, cloth,
sand. The rules that keep it cosmetic:

- **One-way coupling, structurally.** Newton runs against the Tier 3 USD
  stage. Agent capsules and plaza walls enter Newton as **kinematic
  colliders** — infinite-mass bodies whose transforms are read from the
  stage (which reads the wire). Newton may push a puddle ripple, a cloth
  awning, a scatter of leaves; nothing Newton owns may push a kinematic
  body, and Newton's outputs write only under `/World/Cosmetics/*` prims.
  The USD observer never reads that scope back; the server has no path to
  it at all. The feedback loop isn't forbidden by policy — it has no wire
  to travel on.
- **Same fate as all dressing:** Newton stalls or crashes → cosmetic prims
  freeze or vanish; agents, entities, and walls (wire-driven) continue.
  The rain fails open; the world does not get wet, and does not care.
- **Placement law inherited from Tier 1:** cosmetic *volumes* (puddles,
  debris fields) follow the PCG rule — visual mass on walkable ground must
  be traversable-looking (a puddle, not a fountain); anything that reads
  as an obstacle belongs on solid-cell footprints or becomes a real server
  Entity on the reliable plane.

## 3. ArtiFixer — Scan-to-Scene Inversion (`artifixer_invert.py`)

The Tier 1 arrow reversed: a noisy point cloud of a REAL plaza →
`plaza.json`, so server collision matches captured masonry. Pipeline:
height-band filter (0.3–2.2 m: what a 0.4 m-radius agent can hit) →
occupancy on the server's own CELL grid → morphological close (heals scan
dropout) → speck removal (a pigeon is not a wall) → **conservative
dilation** (`--safety-margin 1`) → the Tier 1 fuzz-proven `greedy_mesh` →
rects emitted with a 1e-6 inset and a **refuse-to-write round-trip check**:
rasterizing the output must reproduce the decided solid set bit-exactly.

The conservative direction is a decision, not a tuning: a phantom
half-meter costs an agent a detour; a missing half-meter walks an agent
through real masonry on camera. Verified on a 106k-point synthetic scan
with 25% dropout, sensor noise, floor/ceiling clutter, and a planted
speck: **0 true wall cells missed**, phantom mass bounded to the safety
ring, speck rejected, and the emitted 23-rect file ingested by the live
`NavGrid` bit-identically. The frozen core cannot tell a scanned world
from an authored one — which is the entire point.

**Deployment order (the Tier 1 change-flow, unchanged):** run inverter →
review the `.report.json` → restart orchestrator with the new `--map-file`
→ `test_glasshouse_gen.py` → regenerate Tier 1 visuals → ArtiFixer's
*visual* reconstruction dresses the same footprint in UE5/USD.

## 4. DGX Station — One Desk, Whole Stack (`docker-compose-dgx.yml`)

GB300-class coherent memory collapses the RunPod GPU-partition puzzle:
every service pins device 0; no TP split; models, TTS, embeddings, vector,
graph, telemetry, and (headroom permitting) the render client share the
box. The migration is a compose swap — no engine changes.

**The TTFT law, promoted from runbook step to boot dependency:**
`profile-gate` is a one-shot service running `profile_silicon.py
--min-knee 10` against live sglang; the orchestrator `depends_on` it with
`service_completed_successfully`. No profile → no heartbeat, by topology —
there is deliberately no override flag. The `--min-knee` floor exists
because this tier's demo exposed a gap: a model with knee 6 previously got
a polite recommendation (`aimd_max_limit=5`) and a green exit — but fifty
agents behind five admission slots is a queue, not a plaza. Verified both
directions: knee-6 model → exit 3, UNSERVABLE, orchestrator never starts;
knee-40 model → exit 0, `aimd_max_limit=36` recommended.

**Nemotron guidance:** set `PANOPTICON_MODEL` in `.env` (the compose
refuses to boot without it — a forced choice, like the passwords). Start
with a small/quantized variant; the 550 B-class Ultra tier is an
orchestration brain, not a 50-agent servant — its knee will not clear the
floor, and the gate will tell you so before the plaza finds out. The
Director/goal daemons could someday call a big model at Q3 cadence; that
is a Phase-12 discussion, not a config edit.

```bash
# DGX runbook
cd deploy && ./bootstrap.sh                    # unchanged
echo "PANOPTICON_MODEL=<nemotron-variant>" >> .env
docker compose -f docker-compose-dgx.yml --profile obs up -d
docker compose -f docker-compose-dgx.yml logs -f profile-gate   # the law
# gate exit 0 → orchestrator ignites automatically; exit 3 → pick again
python3 glasshouse/usd_observer.py ... &       # observers as before
python3 glasshouse/motion_sidecar.py &         # Tier 2 local inference
python3 glasshouse/cosmos_director.py ... &    # Tier 4, detached
```

## 5. Provenance Summary — What May Claim to Be Real

| Artifact | Status | Guarantee |
|---|---|---|
| Wire streams / USD `--record` stages | **Truth** | Authoritative state, tick-exact |
| UE5 / USD renders of that state | Faithful depiction | Geometry parity-proven; positions are wire truth |
| Newton cosmetics | Decoration | One-way, `/World/Cosmetics` only |
| Cosmos clips | **Dramatization** | Drift ≤ 1.5 u or destroyed; tagged, detector-verified ≥ 0.8, hashed sidecar — or never published |

The frontier is open. The ground truth is not negotiable. That is the
whole specification, and everything above is its consequences.
