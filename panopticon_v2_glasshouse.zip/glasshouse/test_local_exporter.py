"""Tier 5 bake verification.
1. FLUSH   — a REAL child process running the Tier 3 UsdObserver is
             SIGINT'd; quiescence-wait + reopen validation returns a
             truthful stage summary; the parent never trusted the signal.
2. GRAPH   — a seeded GraphSource exports to SQLite: schema, counts,
             consolidation lineage (derivations), tombstone fields,
             affinity clamp values; file is 0444 with the PANO app id.
3. BUNDLE  — bake() end-to-end (fake graph, injected entities): manifest
             hashes verify against the artifacts byte-for-byte.
"""
import asyncio, hashlib, importlib.util, json, os, pathlib, sqlite3
import subprocess, sys, tempfile, time

spec = importlib.util.spec_from_file_location(
    "local_exporter", pathlib.Path("glasshouse/local_exporter.py"))
lx = importlib.util.module_from_spec(spec)
sys.modules["local_exporter"] = lx
spec.loader.exec_module(lx)

# ---- 1. real child observer, real signal, real flush ----------------------
CHILD = r'''
import signal, struct, sys, time, types
sys.path.insert(0, "/home/claude")
import importlib.util
spec = importlib.util.spec_from_file_location(
    "usd_observer", "/home/claude/glasshouse/usd_observer.py")
uo = importlib.util.module_from_spec(spec)
sys.modules["usd_observer"] = uo
spec.loader.exec_module(uo)
import broadcaster as bc
obs = uo.UsdObserver(sys.argv[1], record_path=sys.argv[1], map_path=None)
def frame(t):
    out = bytearray(struct.pack(bc.HEADER_FMT, t, 1))
    out += struct.pack(bc.AGENT_FMT, bc.compact_wire_id("agent_000"),
                       10.0 + t*0.05, 20.0, 1.0, 0.0, 0)
    return bytes(out)
try:
    t = 0
    while True:
        t += 1
        obs.on_data(types.SimpleNamespace(data=frame(t), topic=bc.DATA_TOPIC))
        if t % 10 == 0: obs.sync()
        time.sleep(0.01)
        print(f"tick {t}", flush=True)
except KeyboardInterrupt:
    pass
finally:
    obs.sync(); obs.stage.Save()
'''
stage = tempfile.mktemp(suffix=".usda")
child_path = pathlib.Path("/tmp/child_obs.py"); child_path.write_text(CHILD)
proc = subprocess.Popen([sys.executable, str(child_path), stage],
                        stdout=subprocess.PIPE, text=True)
for line in proc.stdout:
    if line.startswith("tick 40"): break          # a real running session
info = lx.flush_usd_observer(pathlib.Path(stage), proc.pid, timeout_s=15)
proc.wait(timeout=10)
assert proc.returncode == 0
assert info["end_time_code"] >= 40 and info["timecodes_per_second"] == 20.0
assert info["agent_prims"] == 1
print(f"PASS flush: SIGINT → child saved → quiescence verified → stage "
      f"reopened (end={info['end_time_code']:.0f}, 20 codes/s)")

# ---- 2. graph export -------------------------------------------------------
class FakeGraph:
    ROWS = {
        "agents": [{"id": f"agent_{i:03d}"} for i in range(3)],
        "beliefs": [{"agent_id": "agent_000",
                     "text": "the fountain brings luck",
                     "importance": 0.9, "updated_at": 111.0}],
        "memories": [
            {"id": "m1", "agent_id": "agent_000", "summary": "saw the relic",
             "t": 10.0, "location": "plaza", "consolidated": False,
             "archived_at": 99.0, "consolidated_into": "c1",
             "source_count": None},
            {"id": "c1", "agent_id": "agent_000",
             "summary": "the relic matters", "t": 99.0, "location": "plaza",
             "consolidated": True, "archived_at": None,
             "consolidated_into": None, "source_count": 3}],
        "derivations": [{"consolidated_id": "c1", "source_id": "m1"}],
        "relationships": [{"agent_id": "agent_000", "other_id": "agent_001",
                           "affinity": 1.0, "last_reason": "shared the vault",
                           "updated_at": 120.0}],
        "observations": [{"agent_id": "agent_001", "location": "fountain",
                          "at": 5.0, "summary": "arrived"}],
    }
    async def rows(self, table, query): return list(self.ROWS[table])
    async def close(self): pass

db = pathlib.Path(tempfile.mktemp(suffix=".db"))
counts = asyncio.run(lx.export_graph(FakeGraph(), db, pause_s=0))
assert counts == {"agents": 3, "beliefs": 1, "memories": 2,
                  "derivations": 1, "relationships": 1, "observations": 1}
assert oct(db.stat().st_mode)[-3:] == "444"
conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
assert conn.execute("PRAGMA application_id").fetchone()[0] == lx.APPLICATION_ID
# the codex queries the game will actually run:
belief = conn.execute("SELECT text, importance FROM beliefs WHERE "
                      "agent_id='agent_000'").fetchone()
assert belief == ("the fountain brings luck", 0.9)
lineage = conn.execute(
    "SELECT m.summary, s.summary FROM derivations d "
    "JOIN memories m ON m.id=d.consolidated_id "
    "JOIN memories s ON s.id=d.source_id").fetchone()
assert lineage == ("the relic matters", "saw the relic")
tomb = conn.execute("SELECT archived_at, consolidated_into FROM memories "
                    "WHERE id='m1'").fetchone()
assert tomb == (99.0, "c1")
aff = conn.execute("SELECT affinity, last_reason FROM relationships"
                   ).fetchone()
assert aff == (1.0, "shared the vault")
conn.close()
print("PASS graph: schema + counts exact; belief/lineage/tombstone/affinity "
      "queries answer; 0444 + PANO app id")

# ---- 3. full bake ----------------------------------------------------------
out = pathlib.Path(tempfile.mkdtemp())
class Args: pass
a = Args(); a.out = str(out); a.usd_stage = stage; a.usd_observer_pid = None
ents = {"key01": {"id": "key01", "kind": "key", "x": 3.0, "y": 4.0,
                  "owner_id": "agent000", "version": 7,
                  "state": {"locked": True}}}
bundle = asyncio.run(lx.bake(a, graph_source=FakeGraph(), entities=ents))
man = json.loads((bundle / "manifest.json").read_text())
for name, meta in man["artifacts"].items():
    actual = hashlib.sha256((bundle / name).read_bytes()).hexdigest()
    assert actual == meta["sha256"], name
assert man["entity_count"] == 1 and man["graph_counts"]["agents"] == 3
assert man["stage"]["end_time_code"] >= 40
ej = json.loads((bundle / "entities.json").read_text())
assert ej["entities"]["key01"]["state"]["locked"] is True
print("PASS bundle: session.usda + world.db + entities.json + manifest — "
      "every hash verifies byte-for-byte")
print("\nALL TIER 5 EXPORTER TESTS PASSED")
