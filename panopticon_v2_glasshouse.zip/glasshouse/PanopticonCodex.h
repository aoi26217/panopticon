// ============================================================================
// Project Panopticon — Tier 5: The Codex
// glasshouse/PanopticonCodex.h
//
// The player clicks a pawn; this class answers who she was. Strictly the
// SQLite read path over the baked world.db, exposed to Blueprint for the
// codex UI. Three disciplines:
//
//  1. READ-ONLY, REFUSED OTHERWISE. The database opens in ReadOnly mode
//     and the open is REJECTED unless PRAGMA application_id == 'PANO'
//     (0x50414E4F — stamped by local_exporter.py). A random SQLite file
//     is not a world; a tampered bundle already failed the manifest hash
//     in FBakedPlaybackSource, and this is the second lock on the same
//     door.
//
//  2. THE WIRE-ID BRIDGE. Pawns are keyed by the 8-byte compacted wire id
//     ("agent000"); the graph stores server ids ("agent_000"). At open,
//     the codex builds Compact→Server from the agents table using a
//     FAITHFUL mirror of entities.compact_wire_id — strip non-
//     alphanumerics, keep the LAST 8 (the discriminating tail), which is
//     the detail that bites anyone who mirrors it from memory. A
//     collision (two server ids compacting identically) aborts the open,
//     exactly as the broadcaster registry aborts at startup: better no
//     codex than the wrong agent's soul.
//
//  3. PREPARED ONCE, STEPPED FOREVER. The four queries are prepared at
//     open and reused; a codex page is microseconds of indexed lookups
//     (local_exporter built the indexes), never a UI hitch mid-playback.
//
// Dependency: the engine's SQLiteCore plugin ("SQLiteCore" in Build.cs).
// ============================================================================

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "SQLiteDatabase.h"
#include "PanopticonCodex.generated.h"

USTRUCT(BlueprintType)
struct FCodexBelief
{
    GENERATED_BODY()
    UPROPERTY(BlueprintReadOnly, Category="Codex") FString Text;
    UPROPERTY(BlueprintReadOnly, Category="Codex") float   Importance = 0.f;
    UPROPERTY(BlueprintReadOnly, Category="Codex") float   UpdatedAt  = 0.f;
};

USTRUCT(BlueprintType)
struct FCodexRelation
{
    GENERATED_BODY()
    UPROPERTY(BlueprintReadOnly, Category="Codex") FString OtherAgentId;
    UPROPERTY(BlueprintReadOnly, Category="Codex") FString OtherWireId;
    UPROPERTY(BlueprintReadOnly, Category="Codex") float   Affinity = 0.f;
    // A human sentence — the consolidation LLM wrote it the night it
    // happened ("shared the vault", "took the relic first").
    UPROPERTY(BlueprintReadOnly, Category="Codex") FString LastReason;
};

USTRUCT(BlueprintType)
struct FCodexMemory
{
    GENERATED_BODY()
    UPROPERTY(BlueprintReadOnly, Category="Codex") FString Id;
    UPROPERTY(BlueprintReadOnly, Category="Codex") FString Summary;
    UPROPERTY(BlueprintReadOnly, Category="Codex") float   T = 0.f;
    UPROPERTY(BlueprintReadOnly, Category="Codex") FString Location;
    UPROPERTY(BlueprintReadOnly, Category="Codex") bool    bConsolidated = false;
    // Tombstones ARE content: render archived memories faded — the player
    // watches raw moments dissolve into the beliefs they became.
    UPROPERTY(BlueprintReadOnly, Category="Codex") bool    bArchived = false;
    UPROPERTY(BlueprintReadOnly, Category="Codex") FString ConsolidatedInto;
};

UCLASS()
class GLASSHOUSE_API UPanopticonCodex : public UGameInstanceSubsystem
{
    GENERATED_BODY()

public:
    // Open <BundleDir>/world.db. False (with log) on: missing file, open
    // failure, wrong application_id, missing tables, wire-id collision.
    UFUNCTION(BlueprintCallable, Category="Panopticon|Codex")
    bool OpenBundle(const FString& BundleDir);

    UFUNCTION(BlueprintPure, Category="Panopticon|Codex")
    bool IsOpen() const { return bOpen; }

    // ---- The four queries (pawn click → these four panels) ---------------
    // All take the WIRE id the pawn carries; the bridge resolves it.
    UFUNCTION(BlueprintCallable, Category="Panopticon|Codex")
    TArray<FCodexBelief> GetBeliefs(const FString& WireId);

    UFUNCTION(BlueprintCallable, Category="Panopticon|Codex")
    TArray<FCodexRelation> GetRelations(const FString& WireId);

    // Sources a consolidated memory was distilled from (DERIVED_FROM).
    UFUNCTION(BlueprintCallable, Category="Panopticon|Codex")
    TArray<FCodexMemory> GetLineage(const FString& ConsolidatedMemoryId);

    // Every memory, chronological, archived flagged for faded rendering.
    UFUNCTION(BlueprintCallable, Category="Panopticon|Codex")
    TArray<FCodexMemory> GetLifeStory(const FString& WireId);

    // Roster (server ids) + reverse lookup for UI labels.
    UFUNCTION(BlueprintPure, Category="Panopticon|Codex")
    TArray<FString> GetAllAgentIds() const;
    UFUNCTION(BlueprintPure, Category="Panopticon|Codex")
    FString ResolveWireId(const FString& WireId) const;

    virtual void Deinitialize() override;

    // Faithful mirror of entities.compact_wire_id: strip non-alnum, keep
    // the LAST 8 chars. Public + static so tests and labels share it.
    static FString CompactId(const FString& ServerId);

private:
    bool VerifyApplicationId();
    bool BuildWireBridge();          // agents table → Compact→Server map

    FSQLiteDatabase Db;
    bool bOpen = false;
    TMap<FString, FString> WireToServer;
    TArray<FString> AgentIds;

    // Prepared once at open, Reset() + rebound per call.
    FSQLitePreparedStatement StmtBeliefs;
    FSQLitePreparedStatement StmtRelations;
    FSQLitePreparedStatement StmtLineage;
    FSQLitePreparedStatement StmtLifeStory;
};
