"""
Project Panopticon — Tier 4: ArtiFixer Geometry Inversion
==========================================================
glasshouse/artifixer_invert.py

Inverts the Tier 1 workflow: instead of plaza.json → geometry, a noisy 3D
scan of a REAL plaza → plaza.json — so the server's circles-and-grid
collision physics matches the captured physical world exactly.

    python3 artifixer_invert.py --scan site.xyz --out plaza_scanned.json \\
        [--min-points 6] [--safety-margin 1] [--report]

PIPELINE (ArtiFixer-class cleanup, reduced to what collision truth needs —
we do not reconstruct pretty meshes here; ArtiFixer proper does that for the
VISUAL layer. This tool extracts only the thing the server may trust):
  1. HEIGHT BAND   — keep points with z in [0.3 m, 2.2 m]: strips floor,
                     ceiling, and overhead clutter; what remains is what a
                     0.4 m-radius agent can actually collide with.
  2. OCCUPANCY     — bin XY into the server's own CELL grid (imported from
                     generate_plaza → mirrors navigation.NavGrid). A cell is
                     solid when it holds ≥ min_points (rejects stray noise).
  3. MORPHOLOGY    — close (dilate→erode, r=1): heals scan dropout holes in
                     wall faces without inventing free-standing mass; then
                     drop connected specks smaller than min_component cells
                     (a pigeon is not a wall).
  4. SAFETY MARGIN — dilate the final solid set by --safety-margin cells.
                     THE CONSERVATIVE DIRECTION IS A DECISION, NOT A TUNING:
                     when scan and truth disagree, we err toward SOLID. A
                     phantom half-meter of wall costs an agent a detour; a
                     missing half-meter walks an agent through real masonry
                     on camera. Asymmetric costs, asymmetric bias.
  5. RECTS         — greedy_mesh (the Tier 1 mesher, fuzz-proven against the
                     live NavGrid) decomposes the solid set into rectangles,
                     emitted with a 1e-6 inset so that rasterizing the JSON
                     reproduces the solid set EXACTLY (the round-trip
                     contract, asserted before writing the file).

The emitted file is an ordinary plaza.json: the server needs no new code,
no new flags — the frozen core cannot tell a scanned world from an authored
one. That is the point.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from collections import deque
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from generate_plaza import CELL, WORLD_SIZE, greedy_mesh, rasterize  # noqa: E402

Z_MIN, Z_MAX = 0.3, 2.2


def load_scan(path: Path) -> list[tuple[float, float, float]]:
    """Whitespace/comma xyz per line; blank lines and #comments skipped;
    malformed lines counted and dropped (a scan is untrusted input)."""
    pts, bad = [], 0
    for line in path.read_text().splitlines():
        line = line.replace(",", " ").strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        try:
            x, y, z = float(parts[0]), float(parts[1]), float(parts[2])
            if math.isfinite(x) and math.isfinite(y) and math.isfinite(z):
                pts.append((x, y, z))
            else:
                bad += 1
        except (ValueError, IndexError):
            bad += 1
    if bad:
        print(f"[artifixer] dropped {bad} malformed points")
    return pts


def occupancy(pts, n: int, min_points: int) -> bytearray:
    counts = [0] * (n * n)
    for x, y, z in pts:
        if not (Z_MIN <= z <= Z_MAX) or not (0 <= x < n * CELL) \
                or not (0 <= y < n * CELL):
            continue
        counts[int(y / CELL) * n + int(x / CELL)] += 1
    return bytearray(1 if c >= min_points else 0 for c in counts)


def _shift(grid: bytearray, n: int, expand: bool, r: int = 1) -> bytearray:
    out = bytearray(n * n)
    for cy in range(n):
        for cx in range(n):
            vals = [grid[yy * n + xx]
                    for yy in range(max(0, cy - r), min(n, cy + r + 1))
                    for xx in range(max(0, cx - r), min(n, cx + r + 1))]
            out[cy * n + cx] = (1 if any(vals) else 0) if expand \
                else (1 if all(vals) else 0)
    return out


def close(grid: bytearray, n: int) -> bytearray:
    return _shift(_shift(grid, n, expand=True), n, expand=False)


def drop_specks(grid: bytearray, n: int, min_component: int) -> bytearray:
    out = bytearray(grid)
    seen = bytearray(n * n)
    for start in range(n * n):
        if not out[start] or seen[start]:
            continue
        comp, q = [start], deque([start])
        seen[start] = 1
        while q:
            i = q.popleft()
            cy, cx = divmod(i, n)
            for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                yy, xx = cy + dy, cx + dx
                j = yy * n + xx
                if 0 <= yy < n and 0 <= xx < n and out[j] and not seen[j]:
                    seen[j] = 1
                    comp.append(j)
                    q.append(j)
        if len(comp) < min_component:
            for i in comp:
                out[i] = 0
    return out


def boxes_to_rects(boxes) -> list[list[float]]:
    """Inclusive cell boxes → world rects with a 1e-6 inset so the server's
    int(x/cell) rasterization lands on exactly the same cells."""
    return [[cx0 * CELL, cy0 * CELL,
             (cx1 + 1) * CELL - 1e-6, (cy1 + 1) * CELL - 1e-6]
            for cx0, cy0, cx1, cy1 in boxes]


def invert(pts, min_points: int, safety_margin: int,
           min_component: int = 4) -> tuple[list[list[float]], dict]:
    n = max(1, int(math.ceil(WORLD_SIZE / CELL)))
    raw = occupancy(pts, n, min_points)
    cleaned = drop_specks(close(raw, n), n, min_component)
    final = cleaned
    for _ in range(safety_margin):
        final = _shift(final, n, expand=True)
    boxes = greedy_mesh(n, final)
    rects = boxes_to_rects(boxes)

    # THE ROUND-TRIP CONTRACT: rasterizing what we emit must reproduce what
    # we decided, bit-exact, using the same fuzz-proven rasterizer the
    # server mirrors. Refuse to write a file that fails its own physics.
    n2, back = rasterize(rects)
    if (n2, bytes(back)) != (n, bytes(final)):
        raise RuntimeError("round-trip parity failed — refusing to emit")

    report = {"points": len(pts), "grid_n": n,
              "raw_solid": sum(raw), "cleaned_solid": sum(cleaned),
              "final_solid": sum(final), "rects": len(rects),
              "safety_margin_cells": safety_margin, "roundtrip_exact": True}
    return rects, report


def main() -> int:
    ap = argparse.ArgumentParser(description="scan → plaza.json inversion")
    ap.add_argument("--scan", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--min-points", type=int, default=6)
    ap.add_argument("--safety-margin", type=int, default=1,
                    help="cells of conservative dilation (0 disables)")
    ap.add_argument("--min-component", type=int, default=4)
    ap.add_argument("--report", action="store_true")
    args = ap.parse_args()

    pts = load_scan(Path(args.scan))
    rects, report = invert(pts, args.min_points, args.safety_margin,
                           args.min_component)
    Path(args.out).write_text(json.dumps(rects) + "\n")
    print(f"[artifixer] {report}")
    print(f"[artifixer] wrote {args.out} — deploy: restart orchestrator with "
          f"--map-file, run test_glasshouse_gen.py, regen Tier 1. The server "
          f"now collides with the real world.")
    if args.report:
        Path(args.out + ".report.json").write_text(json.dumps(report, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
