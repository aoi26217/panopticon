// ============================================================================
// Project Panopticon — Tier 5: Local Playback Source
// glasshouse/LocalPlayback.h
//
// How the shipped game's MagnusObserver runs WITHOUT the network: the
// LiveKit ingress is replaced by a source that reads the baked bundle —
// and nothing else changes. The architecture of this file is one idea:
//
//   THE BAKED SOURCE SPEAKS THE WIRE'S LANGUAGE.
//
// FBakedPlaybackSource reads /World/Agents/*/xformOp timeSamples from
// session.usda and synthesizes FAgentSnapshots BIT-COMPATIBLE with what
// the LiveKit path produced: positions from the samples, velocities by
// finite difference over the 20 Hz timecodes — which are exactly the
// Hermite tangents the live wire carried, because the server computed its
// wire velocities from the same consecutive positions. Downstream, the
// ENTIRE Tier 1–2 stack runs verbatim and unaware:
//
//     baked source ──► FAgentChannel (Prev/Latest) ──► EvalHermite ──►
//     actor transform ──► UGlasshouseMotionController::DriveSkeleton
//     (features from tangents, EXACTLY as live) ──► motion sidecar ──►
//     walking pawns, offline, on a consumer GPU
//
// The offline pawns therefore walk with the same Tier 2 gaits, degrade
// with the same fail-open blend, and stand at the same positions as the
// night the session was recorded — because the bundle is truth, and the
// playback layer is one more client of it.
// ============================================================================

#pragma once

#include "CoreMinimal.h"
#include "MagnusObserver.h"          // FAgentChannel, FAgentSnapshot — reused
#include "LocalPlayback.generated.h"

// ---------------------------------------------------------------------------
// The ingress seam. AMagnusObserver gains exactly one abstraction: where
// snapshots come from. Live = the existing LiveKit callbacks wrapped;
// Baked = this file. Selected by a single config bool / launch arg
// (-PanopticonBundle=<dir>); no other observer code changes.
// ---------------------------------------------------------------------------
class IPanopticonIngress
{
public:
    virtual ~IPanopticonIngress() = default;
    virtual void Tick(float DeltaTime) = 0;      // pumps snapshots into
    virtual bool IsLive() const = 0;             // the shared channel map
};

UENUM(BlueprintType)
enum class EPlaybackState : uint8 { Playing, Paused, Scrubbing };

// ---------------------------------------------------------------------------
// FBakedPlaybackSource — session.usda → synthesized wire snapshots.
//
// LOAD (once, async, loading screen):
//   * Open the stage (SDK-SEAM: UnrealUSDWrapper / UsdStage::Open — the
//     engine's bundled USD libs; no runtime pxr distribution needed).
//   * For each /World/Agents/<id> Xform: read ALL translate timeSamples
//     into a flat TArray<FVector2f> indexed by (timeCode - start). 20 Hz
//     × a 2-hour session × 51 pawns ≈ 30 MB of floats: preload whole.
//   * Read panopticon:speaking timeSamples where present → per-agent
//     bitset by tick (the flag the wire carried; drives Talk gestures
//     and dialogue-moment UI offline).
//
// PLAYBACK TICK (the wire impersonation):
//   PlaybackClock advances at 1.0× (or paused/scrubbed). Whenever it
//   crosses a timecode boundary T:
//     Snapshot.Pos   = Samples[T]
//     Snapshot.Vel   = (Samples[T] - Samples[T-1]) * TICKS_PER_SECOND
//     Snapshot.Flags = SpeakingBits[T] ? FLAG_SPEAKING : 0
//     Channel.Prev = Channel.Latest; Channel.Latest = Snapshot;
//     Channel.LatestAt = Now;
//   — i.e. one synthesized 20 Hz "frame" per crossed timecode, delivered
//   through the SAME channel struct the network filled. EvalHermite and
//   the motion controller cannot tell the difference; that is the test.
//
// SCRUB: SetPlaybackTime(Seconds) → clock jump → the NEXT crossed
//   timecode reseeds Prev=Latest=Samples[T] (a clean cut, exactly like a
//   live late-join), and Tier 2's blend ramps back in over ~300 ms. Fast
//   binary-search into the flat arrays; scrubbing a 2-hour session is an
//   array index, not a file seek.
//
// FAIL-OPEN, inherited: a missing agent prim renders nothing; a truncated
// sample array clamps to its last frame (the pawn stands where the
// recording ended); a corrupt stage aborts to menu with the manifest
// shown — the ONE place the bundle fails closed: the game verifies
// manifest.json SHA-256s at load and refuses a tampered bundle, because
// the bundle is the ground truth the whole offline product stands on.
// ---------------------------------------------------------------------------
class GLASSHOUSE_API FBakedPlaybackSource : public IPanopticonIngress
{
public:
    bool  LoadBundle(const FString& BundleDir);  // verifies manifest hashes
    virtual void Tick(float DeltaTime) override;
    virtual bool IsLive() const override { return false; }

    // Transport controls (bound to game UI)
    void  SetState(EPlaybackState S);
    void  SetPlaybackTime(double Seconds);       // scrub (clean-cut reseed)
    double GetDuration() const;                  // EndTimeCode / 20.0

private:
    TMap<FString, TArray<FVector2f>> Samples;    // per agent, per tick
    TMap<FString, TBitArray<>>       Speaking;
    double StartCode = 0, EndCode = 0, Clock = 0;
    int32  LastEmitted = -1;
    EPlaybackState State = EPlaybackState::Playing;
};

// ---------------------------------------------------------------------------
// FSQLiteBeliefCodex — world.db → the in-game lore codex.
//
// Opened READ-ONLY (SDK-SEAM: UE SQLiteCore plugin, OpenMode ReadOnly)
// and the open REFUSES any db whose PRAGMA application_id != 'PANO'
// (0x50414E4F) — the exporter stamps it; a random sqlite file is not a
// world. All queries are the indexed lookups the exporter built indexes
// for; each returns in microseconds on consumer hardware:
//
//   Beliefs(agent)        SELECT text, importance FROM beliefs
//                         WHERE agent_id=? ORDER BY importance DESC
//   Relations(agent)      SELECT other_id, affinity, last_reason
//                         FROM relationships WHERE agent_id=?
//   Lineage(consolidated) SELECT s.summary FROM derivations d JOIN
//                         memories s ON s.id=d.source_id
//                         WHERE d.consolidated_id=?
//   LifeStory(agent)      memories WHERE agent_id=? ORDER BY t
//                         (archived_at NOT NULL rendered as faded —
//                          tombstones ARE content: the player watches
//                          raw moments fade into the beliefs they became)
//
// This is the game's quiet magic: click a pawn mid-playback, and the
// codex shows what she believed, whom she resented and why (last_reason
// is a human sentence — the consolidation LLM wrote it), and which
// forgotten afternoons became her convictions. None of it is generated
// on the player's machine; all of it HAPPENED, in the cloud, that night.
//
// FEntitySpawnTable — entities.json → BeginPlay spawn list: kind → mesh
// class, position, owner (attach to pawn if carried), state (locked doors
// render locked). Static final truth; the recording's world, furnished.
// ---------------------------------------------------------------------------

// INTEGRATION DIFF (complete):
//   AMagnusObserver::BeginPlay():
//     - Ingress = MakeUnique<FLiveKitIngress>(...);        // (was inline)
//     + Ingress = FParse::Value(Cmd, TEXT("PanopticonBundle="), Dir)
//     +   ? MakeUnique<FBakedPlaybackSource>(Dir)
//     +   : MakeUnique<FLiveKitIngress>(...);
//   AMagnusObserver::Tick():
//     + Ingress->Tick(DeltaTime);                          // before Hermite
//   Everything else — EvalHermite, MotionController, entity meshes,
//   Tier 1 plaza — byte-identical between the live show and the boxed game.
