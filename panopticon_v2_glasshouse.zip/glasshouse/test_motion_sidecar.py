"""Tier 2 sidecar verification (headless, live UDP loopback).

1. WIRE      — struct sizes match the C++ static_asserts (10/28/8);
               request/response roundtrip is bit-faithful; malformed and
               enum-invalid datagrams dropped and counted.
2. SEQ       — stale/reordered requests refused; responses carry the seq.
3. COALESCE  — a slow model + a burst of requests: only the NEWEST batch is
               inferred; intermediates counted as coalesced, never queued.
4. FAIL-OPEN — a model that raises produces SILENCE (no datagram), a
               counted failure, and full recovery on the next request.
5. GAIT      — stub model: deterministic across replays; phase continuous;
               cadence scales with speed (stride-warp contract); idle ≈
               still; gesture channels move only when conditioned.
"""
import asyncio, importlib.util, math, pathlib, socket, struct, time

spec = importlib.util.spec_from_file_location(
    "motion_sidecar", pathlib.Path("glasshouse/motion_sidecar.py"))
import sys
ms = importlib.util.module_from_spec(spec)
sys.modules["motion_sidecar"] = ms          # dataclasses need this registered
spec.loader.exec_module(ms)

def req(seq, pawns, dt=1/30):
    out = bytearray(struct.pack(ms.REQ_HDR, seq, len(pawns), dt))
    for (aid, speed, heading, turn, accel, loco, gest, flags) in pawns:
        out += struct.pack(ms.REQ_PAWN, aid, speed, heading, turn, accel,
                           loco, gest, flags, 0)
    return bytes(out)

def parse_resp(data):
    seq, count, status, _ = struct.unpack_from(ms.RESP_HDR, data, 0)
    off = ms.RESP_HDR_SIZE
    poses = {}
    for _ in range(count):
        aid, n = struct.unpack_from("<8sH", data, off); off += 10
        poses[aid] = list(struct.unpack_from(f"<{n}f", data, off)); off += 4*n
    assert off == len(data)
    return seq, status, poses

PAWN = lambda i, speed, gest=0: (f"agent{i:03d}".encode(), speed, 0.5,
                                 0.0, 0.0, 1, gest, 0)

async def with_sidecar(model, fn):
    loop = asyncio.get_running_loop()
    transport, proto = await loop.create_datagram_endpoint(
        lambda: ms.MotionSidecar(model), local_addr=("127.0.0.1", 0))
    port = transport.get_extra_info("sockname")[1]
    worker = asyncio.create_task(proto.run_worker())
    cli = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    cli.bind(("127.0.0.1", 0)); cli.setblocking(False)
    try:
        await fn(cli, port, proto)
    finally:
        worker.cancel(); transport.close(); cli.close()

async def recv(cli, timeout=0.5):
    loop = asyncio.get_running_loop()
    try:
        return await asyncio.wait_for(loop.sock_recv(cli, 65536), timeout)
    except asyncio.TimeoutError:
        return None

async def test_wire_and_seq():
    assert (ms.REQ_HDR_SIZE, ms.REQ_PAWN_SIZE, ms.RESP_HDR_SIZE) == (10, 28, 8)
    async def fn(cli, port, proto):
        loop = asyncio.get_running_loop()
        addr = ("127.0.0.1", port)
        await loop.sock_sendto(cli, req(5, [PAWN(0, 1.5), PAWN(1, 0.0)]), addr)
        data = await recv(cli)
        seq, status, poses = parse_resp(data)
        assert seq == 5 and status == ms.STATUS_STUB and len(poses) == 2
        assert all(len(v) == ms.StubGaitModel.N_FLOATS for v in poses.values())
        # stale + malformed + bad-enum all dropped, counted, unanswered
        await loop.sock_sendto(cli, req(4, [PAWN(0, 1.0)]), addr)
        await loop.sock_sendto(cli, b"\x01\x02garbage", addr)
        await loop.sock_sendto(cli, req(6, [(b"agent000", 1, 0, 0, 0,
                                             9, 0, 0)]), addr)  # loco=9
        assert await recv(cli, 0.3) is None
        assert proto.stats.stale == 1 and proto.stats.malformed == 2
    await with_sidecar(ms.StubGaitModel(), fn)
    print("PASS wire+seq: sizes 10/28/8, roundtrip exact, stale/garbage "
          "refused unanswered")

async def test_coalescing():
    class SlowModel(ms.StubGaitModel):
        def infer(self, dt, batch):
            time.sleep(0.15)                      # 5× slower than 30 Hz
            return super().infer(dt, batch)
    async def fn(cli, port, proto):
        loop = asyncio.get_running_loop()
        addr = ("127.0.0.1", port)
        for s in range(10, 20):                   # burst of 10
            await loop.sock_sendto(cli, req(s, [PAWN(0, 2.0)]), addr)
            await asyncio.sleep(0.005)
        got = []
        while (d := await recv(cli, 0.4)) is not None:
            got.append(parse_resp(d)[0])
        assert proto.stats.coalesced >= 6, proto.stats
        assert proto.stats.inferred <= 4
        assert got[-1] == 19                      # the newest batch answered
    await with_sidecar(SlowModel(), fn)
    print("PASS coalescing: 10-burst vs slow model → newest inferred, "
          "intermediates superseded, no queue")

async def test_fail_open():
    class Bomb(ms.StubGaitModel):
        def __init__(self): super().__init__(); self.arm = True
        def infer(self, dt, batch):
            if self.arm: self.arm = False; raise RuntimeError("VRAM gone")
            return super().infer(dt, batch)
    async def fn(cli, port, proto):
        loop = asyncio.get_running_loop()
        addr = ("127.0.0.1", port)
        await loop.sock_sendto(cli, req(1, [PAWN(0, 1.0)]), addr)
        assert await recv(cli, 0.3) is None       # silence, not an error frame
        assert proto.stats.model_failures == 1
        await loop.sock_sendto(cli, req(2, [PAWN(0, 1.0)]), addr)
        seq, _, _ = parse_resp(await recv(cli))
        assert seq == 2                           # full recovery
    await with_sidecar(Bomb(), fn)
    print("PASS fail-open: model explosion → silence + counter; next "
          "request served normally")

async def test_gait_contract():
    aid = b"agent000"
    def run(speeds, gest=0):
        m = ms.StubGaitModel()
        return [m.infer(1/30, [(ms.PawnConditioning(aid, s, 0, 0, 0, 1,
                                                    gest, 0))])[0][1]
                for s in speeds]
    a = run([1.0]*60); b = run([1.0]*60)
    assert a == b                                  # deterministic
    hip = [p[0] for p in a]
    zero_x = sum(1 for i in range(1, 60) if hip[i-1] * hip[i] < 0)
    fast_x = sum(1 for i, p in enumerate(run([2.5]*60)[1:], 1)
                 if run([2.5]*60)[i-1][0] * p[0] < 0)
    slow = run([2.5]*60); fast_hip = [p[0] for p in slow]
    fast_x = sum(1 for i in range(1, 60)
                 if fast_hip[i-1] * fast_hip[i] < 0)
    assert fast_x > zero_x                         # cadence tracks speed
    idle = run([0.0]*30)
    assert max(abs(p[0]) for p in idle) < 0.05     # idle: legs still
    talk = run([0.0]*30, gest=5)
    assert any(abs(p[10]) > 0.01 for p in talk)    # head moves when talking
    still = run([0.0]*30, gest=0)
    assert all(abs(p[10]) < 1e-6 or abs(p[10]) < 0.001
               for p in still[:1])                  # and not otherwise (t0)
    print(f"PASS gait: deterministic, cadence {zero_x}→{fast_x} crossings "
          f"walk→run, idle still, talk animates the head")

async def main():
    await test_wire_and_seq()
    await test_coalescing()
    await test_fail_open()
    await test_gait_contract()
    print("\nALL TIER 2 SIDECAR TESTS PASSED")

asyncio.run(main())
