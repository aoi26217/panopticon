"""Tier 4 inversion verification: synthesize a hostile scan of a KNOWN
plaza, invert it, and prove the derived collision truth is (a) round-trip
exact, (b) conservative — no real wall ever reads as clear — and (c) sane —
bounded phantom mass, noise rejected, server-loadable."""
import importlib.util, json, math, pathlib, random, sys
spec = importlib.util.spec_from_file_location(
    "artifixer_invert", pathlib.Path("glasshouse/artifixer_invert.py"))
ax = importlib.util.module_from_spec(spec)
sys.modules["artifixer_invert"] = ax
spec.loader.exec_module(ax)
import navigation as nav
from artifixer_invert import CELL, WORLD_SIZE, invert, rasterize

rng = random.Random(42)
GT_RECTS = [[15.0, 0.0, 17.0, 30.0], [30.0, 55.0, 60.0, 58.0],
            [70.0, 10.0, 72.0, 40.0]]
n_gt, gt_solid = rasterize(GT_RECTS)

# --- synthesize the scan: dense wall sampling + dropout + noise + junk ----
pts = []
for x0, y0, x1, y1 in GT_RECTS:                    # wall faces, 0.3-2.2m
    for _ in range(int((x1-x0) * (y1-y0) * 400)):
        if rng.random() < 0.25: continue           # 25% scan dropout holes
        pts.append((rng.uniform(x0, x1) + rng.gauss(0, 0.05),
                    rng.uniform(y0, y1) + rng.gauss(0, 0.05),
                    rng.uniform(0.3, 2.2)))
for _ in range(40000):                             # floor (below band)
    pts.append((rng.uniform(0, 100), rng.uniform(0, 100),
                rng.uniform(0.0, 0.15)))
for _ in range(3000):                              # overhead clutter (above)
    pts.append((rng.uniform(0, 100), rng.uniform(0, 100),
                rng.uniform(2.5, 4.0)))
for _ in range(300):                               # stray noise in band
    pts.append((rng.uniform(0, 100), rng.uniform(0, 100),
                rng.uniform(0.3, 2.2)))
for _ in range(30):                                # a pigeon-sized speck
    pts.append((82.0 + rng.gauss(0, 0.1), 82.0 + rng.gauss(0, 0.1), 1.0))
rng.shuffle(pts)

rects, report = invert(pts, min_points=6, safety_margin=1)
print(f"scan: {len(pts):,} pts → {report}")

# 1. round-trip exactness (the tool asserts it too; verify independently)
n_d, derived = rasterize(rects)
assert report["roundtrip_exact"] and n_d == n_gt
print("PASS roundtrip: emitted JSON rasterizes to the decided solid set")

# 2. CONSERVATIVE: every ground-truth wall cell is solid in the derivation
misses = sum(1 for i in range(n_gt * n_gt) if gt_solid[i] and not derived[i])
assert misses == 0, f"{misses} true wall cells read clear — agents would clip"
print("PASS conservative: 0/{} true wall cells missed — no real masonry "
      "is walkable".format(sum(gt_solid)))

# 3. BOUNDED phantom mass: dilation ring + healed holes only, and the noise
#    speck at (82,82) must be gone
phantom = sum(1 for i in range(n_gt * n_gt) if derived[i] and not gt_solid[i])
assert phantom <= sum(gt_solid) * 2.5, phantom     # ~perimeter ring scale
speck = derived[int(82/CELL) * n_gt + int(82/CELL)]
assert not speck
print(f"PASS bounded: {phantom} phantom cells (safety ring + healing), "
      f"pigeon-speck rejected")

# 4. the emitted file is an ordinary map: server machinery accepts it whole
pathlib.Path("/tmp/plaza_scanned.json").write_text(json.dumps(rects))
g = nav.NavGrid(WORLD_SIZE, CELL)
for r in json.loads(pathlib.Path("/tmp/plaza_scanned.json").read_text()):
    g.add_obstacle_rect(*r)
assert bytes(g._solid) == bytes(derived)
assert g.solid_at(16.0, 15.0) and not g.solid_at(50.0, 25.0)
print(f"PASS server-loadable: NavGrid ingests the {report['rects']}-rect "
      f"file bit-identically; frozen core cannot tell scan from author")
print("\nALL TIER 4 INVERSION TESTS PASSED")
