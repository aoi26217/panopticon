"""
Project Panopticon — Glasshouse Tier 3: The USD Observer
=========================================================
glasshouse/usd_observer.py

A second, parallel observer: joins the LiveKit room as a SUBSCRIBE-ONLY
participant, consumes the same two planes as the UE5 client, and writes a
live USD stage that Omniverse (or usdview, or any USD-speaking DCC) renders.

    python3 usd_observer.py --livekit-url ws://host:7880 \\
        --livekit-api-key KEY --livekit-api-secret SECRET \\
        --stage /tmp/panopticon.usda --map ../deploy/maps/plaza.json \\
        [--record session.usda]

THE INVARIANTS, AS STRUCTURE
  OBSERVER PURITY — the access token carries can_subscribe=True and
    can_publish=False / can_publish_data=False: read-only is enforced by the
    SFU's grant system, not by our good manners. There is no code path that
    sends; there is no permission that could.
  MULTICAST SEMANTICS — "multicast" here is the SFU fan-out: the broadcaster
    publishes once, LiveKit replicates to N observers. This process crashing
    or stalling is invisible to the server and the UE5 client by topology.
    Spatial-plane loss is healed exactly as the UE5 client heals it:
    tick-monotonic rejection + the same Hermite formula (mirrored below)
    riding wire velocities as tangents.
  ZERO DUPLICATED WIRE KNOWLEDGE — header/record formats, flags, and the
    entity decoder are IMPORTED from broadcaster.py and entities.py. If the
    wire ever changes, this observer changes with it or fails to import;
    it cannot silently drift. Plaza geometry uses generate_plaza's
    rasterize/greedy_mesh — the functions fuzz-proven bit-identical to the
    server NavGrid — so all three clients share one geometry truth.

LIVE vs RECORD
  --stage    live view: prims' translate set to Hermite-evaluated "now",
             stage saved at --save-hz (usdview/Omniverse with auto-reload,
             or a Nucleus omni:// URL for true live-layer sync).
  --record   cinematics: every accepted frame ALSO writes a timeSample at
             timeCode = tick (timeCodesPerSecond = 20). The session becomes
             a scrubbable USD animation — point an RTX renderer at it and
             film the plaza in path-traced quality, offline, forever.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import math
import struct
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))  # repo root

from pxr import Gf, Sdf, Usd, UsdGeom                    # noqa: E402
from livekit import api, rtc                             # noqa: E402
from broadcaster import (AGENT_FMT, AGENT_SIZE, DATA_TOPIC,   # noqa: E402
                         FLAG_DEGRADED, FLAG_SPEAKING,
                         HEADER_FMT, HEADER_SIZE)
from entities import ENTITY_TOPIC, decode_entity_deltas  # noqa: E402
from glasshouse.generate_plaza import (CELL, box_to_uu, greedy_mesh,  # noqa: E402
                                       load_map, rasterize)

log = logging.getLogger("panopticon.usd")
TICK_DT = 0.05                    # 20 Hz — EngineConfig.tick_hz
AGENT_HEIGHT = 1.7                # presentation only (meters)


def hermite(p0, p1, v0, v1, alpha: float):
    """Mirror of MagnusObserver::EvalHermite — tangents scaled to the tick
    interval, alpha clamped to 1.5 (brief extrapolation over lost frames)."""
    t = max(0.0, min(1.5, alpha))
    t2, t3 = t * t, t * t * t
    h = (lambda a0, a1, b0, b1:
         a0 * (2 * t3 - 3 * t2 + 1) + b0 * (t3 - 2 * t2 + t)
         + a1 * (-2 * t3 + 3 * t2) + b1 * (t3 - t2))
    return (h(p0[0], p1[0], v0[0] * TICK_DT, v1[0] * TICK_DT),
            h(p0[1], p1[1], v0[1] * TICK_DT, v1[1] * TICK_DT))


class UsdObserver:
    def __init__(self, stage_path: str, record_path: str | None,
                 map_path: str | None) -> None:
        self.stage = Usd.Stage.CreateNew(stage_path)
        UsdGeom.SetStageUpAxis(self.stage, UsdGeom.Tokens.z)
        UsdGeom.SetStageMetersPerUnit(self.stage, 1.0)
        self.stage.SetTimeCodesPerSecond(20.0)           # ticks ARE timecodes
        self.stage.SetStartTimeCode(0)
        self.record = record_path is not None
        if self.record:                                   # record INTO the
            self.stage.GetRootLayer().documentation = "panopticon session"
        self._record_path = record_path
        self.root = UsdGeom.Xform.Define(self.stage, "/World")
        UsdGeom.Scope.Define(self.stage, "/World/Agents")
        UsdGeom.Scope.Define(self.stage, "/World/Entities")
        if map_path:
            self._build_plaza(map_path)
        # snapshot pairs per agent: (prev_pos, prev_vel, pos, vel, recv_at)
        self._agents: dict[str, tuple] = {}
        self._flags: dict[str, int] = {}
        self._entities: dict[str, dict] = {}
        self._prims: dict[str, UsdGeom.Xform] = {}
        self.last_tick = -1
        self.frames = 0
        self.frames_stale = 0
        self.entity_records = 0
        self.saves = 0
        self.save_failures = 0

    # ---- plaza: same rasterizer, same mesher, third client, one truth -----
    def _build_plaza(self, map_path: str) -> None:
        n, solid = rasterize(load_map(Path(map_path)))
        ground = UsdGeom.Cube.Define(self.stage, "/World/Plaza/Ground")
        UsdGeom.XformCommonAPI(ground).SetTranslate((50.0, 50.0, -0.05))
        UsdGeom.XformCommonAPI(ground).SetScale((50.0, 50.0, 0.05))
        for i, box in enumerate(greedy_mesh(n, solid)):
            cx, cy, ex, ey, hz = box_to_uu(box)          # uu = cm
            wall = UsdGeom.Cube.Define(self.stage,
                                       f"/World/Plaza/Wall_{i:03d}")
            xf = UsdGeom.XformCommonAPI(wall)
            xf.SetTranslate((cx / 100, cy / 100, hz / 100))
            xf.SetScale((ex / 100, ey / 100, hz / 100))  # Cube extent ±1

    # ---- ingress (sync callbacks on the event loop; fail-open) -------------
    def on_data(self, packet) -> None:
        try:
            topic = getattr(packet, "topic", "")
            if topic == DATA_TOPIC:
                self._on_state(bytes(packet.data))
            elif topic == ENTITY_TOPIC:
                self._on_entities(bytes(packet.data))
        except Exception:
            log.exception("packet dropped (fail-open)")

    def _on_state(self, data: bytes) -> None:
        if len(data) < HEADER_SIZE:
            return
        tick, count = struct.unpack_from(HEADER_FMT, data, 0)
        if len(data) != HEADER_SIZE + count * AGENT_SIZE or \
                tick <= self.last_tick:
            self.frames_stale += 1                        # torn or reordered
            return
        self.last_tick = tick
        now = time.monotonic()
        off = HEADER_SIZE
        for _ in range(count):
            wid, x, y, vx, vy, flags = struct.unpack_from(AGENT_FMT, data, off)
            off += AGENT_SIZE
            aid = wid.rstrip(b"\x00").decode()
            prev = self._agents.get(aid)
            p_pos, p_vel = (prev[2], prev[3]) if prev else ((x, y), (vx, vy))
            self._agents[aid] = (p_pos, p_vel, (x, y), (vx, vy), now)
            self._flags[aid] = flags
            if self.record:
                self._sample_agent(aid, tick, (x, y), flags)
        self.frames += 1

    def _on_entities(self, data: bytes) -> None:
        _tick, records = decode_entity_deltas(data)       # reliable plane:
        for rec in records:                               # the shipped decoder
            self._entities[rec["id"]] = rec
            self.entity_records += 1

    # ---- USD mutation ------------------------------------------------------
    def _prim(self, kind: str, name: str) -> UsdGeom.Xform:
        key = f"{kind}/{name}"
        prim = self._prims.get(key)
        if prim is None:
            path = f"/World/{kind}/{Sdf.Path(name).name or name}"
            prim = UsdGeom.Xform.Define(self.stage, path)
            shape = (UsdGeom.Capsule if kind == "Agents"
                     else UsdGeom.Cube).Define(self.stage, path + "/geo")
            if kind == "Agents":
                shape.CreateHeightAttr(AGENT_HEIGHT - 0.8)
                shape.CreateRadiusAttr(0.4)               # = server radius
                shape.CreateAxisAttr(UsdGeom.Tokens.z)
            else:
                UsdGeom.XformCommonAPI(shape).SetScale((0.25, 0.25, 0.25))
            self._prims[key] = prim
        return prim

    def _sample_agent(self, aid: str, tick: int, pos, flags: int) -> None:
        prim = self._prim("Agents", aid)
        xf = UsdGeom.XformCommonAPI(prim)
        xf.SetTranslate((pos[0], pos[1], AGENT_HEIGHT / 2), Usd.TimeCode(tick))
        # Flags ride the recording too (Tier 5: offline playback derives
        # Talk gestures and dialogue UI from these, exactly as live).
        prim.GetPrim().CreateAttribute(
            "panopticon:speaking", Sdf.ValueTypeNames.Bool).Set(
            bool(flags & FLAG_SPEAKING), Usd.TimeCode(tick))
        self.stage.SetEndTimeCode(tick)

    def sync(self) -> None:
        """One live-view pass: Hermite-evaluate every agent at wall-clock
        'now', mirror entity truth, save. Any failure is one skipped save."""
        try:
            now = time.monotonic()
            for aid, (p0, v0, p1, v1, recv_at) in self._agents.items():
                alpha = (now - recv_at) / TICK_DT
                x, y = hermite(p0, p1, v0, v1, alpha)
                prim = self._prim("Agents", aid)
                UsdGeom.XformCommonAPI(prim).SetTranslate(
                    (x, y, AGENT_HEIGHT / 2))
                flags = self._flags.get(aid, 0)
                p = prim.GetPrim()
                p.CreateAttribute("panopticon:speaking",
                                  Sdf.ValueTypeNames.Bool).Set(
                    bool(flags & FLAG_SPEAKING))
                p.CreateAttribute("panopticon:degraded",
                                  Sdf.ValueTypeNames.Bool).Set(
                    bool(flags & FLAG_DEGRADED))
            for eid, rec in self._entities.items():
                prim = self._prim("Entities", eid)
                carried = rec["owner_id"] is not None
                UsdGeom.XformCommonAPI(prim).SetTranslate(
                    (rec["x"], rec["y"], 1.2 if carried else 0.15))
                p = prim.GetPrim()
                p.CreateAttribute("panopticon:kind",
                                  Sdf.ValueTypeNames.String).Set(rec["kind"])
                p.CreateAttribute("panopticon:owner",
                                  Sdf.ValueTypeNames.String).Set(
                    rec["owner_id"] or "")
                p.CreateAttribute("panopticon:state",
                                  Sdf.ValueTypeNames.String).Set(
                    json.dumps(rec["state"], separators=(",", ":")))
                p.CreateAttribute("panopticon:version",
                                  Sdf.ValueTypeNames.Int).Set(rec["version"])
            self.stage.Save()
            self.saves += 1
        except Exception:
            self.save_failures += 1
            log.exception("sync skipped (fail-open; next save heals)")


async def amain(args: argparse.Namespace) -> None:
    obs = UsdObserver(args.stage, args.record, args.map)
    token = (api.AccessToken(args.livekit_api_key, args.livekit_api_secret)
             .with_identity("panopticon-usd-observer")
             .with_grants(api.VideoGrants(
                 room_join=True, room=args.room, can_subscribe=True,
                 can_publish=False, can_publish_data=False))   # PURITY
             .to_jwt())
    room = rtc.Room()
    room.on("data_received", obs.on_data)
    await room.connect(args.livekit_url, token)
    log.info("USD observer up: stage=%s record=%s (read-only grant)",
             args.stage, bool(args.record))
    try:
        while True:
            await asyncio.sleep(1.0 / args.save_hz)
            obs.sync()
            if obs.saves % (args.save_hz * 30) == 0 and obs.saves:
                log.info("frames=%d stale=%d entities=%d saves=%d fails=%d",
                         obs.frames, obs.frames_stale, obs.entity_records,
                         obs.saves, obs.save_failures)
    finally:
        await room.disconnect()
        obs.stage.Save()


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s USD %(message)s")
    p = argparse.ArgumentParser(description="Panopticon USD observer")
    p.add_argument("--livekit-url", required=True)
    p.add_argument("--livekit-api-key", required=True)
    p.add_argument("--livekit-api-secret", required=True)
    p.add_argument("--room", default="panopticon")
    p.add_argument("--stage", default="/tmp/panopticon_live.usda",
                   help="local .usda/.usdc path or omni:// Nucleus URL")
    p.add_argument("--record", default=None,
                   help="also write per-tick timeSamples (scrubbable "
                        "session animation) — pass same or separate path")
    p.add_argument("--map", default=None,
                   help="plaza.json → static walls from the parity-proven "
                        "mesher (one geometry truth, three clients)")
    p.add_argument("--save-hz", type=float, default=10.0)
    asyncio.run(amain(p.parse_args()))


if __name__ == "__main__":
    main()
