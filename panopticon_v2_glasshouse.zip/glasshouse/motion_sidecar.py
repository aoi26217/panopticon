"""
Project Panopticon — Glasshouse Tier 2: Motion Inference Sidecar
=================================================================
glasshouse/motion_sidecar.py

A separate OS process on the observer's machine that turns conditioning
batches into skeletal poses. Run alongside the UE client:

    python3 motion_sidecar.py                       # stub gait (no GPU)
    python3 motion_sidecar.py --model <loader>      # real model (see seam)

WHY A SIDECAR (invariant 2, structurally): a motion model that segfaults,
OOMs, or hangs takes down THIS process, not the renderer. The client's
watchdog notices silence, blends to capsule-glide, and the breaker retries
later. Crash containment by address space, not by try/except optimism.

WHY UDP + LATEST-WINS (the Phase 6 logic, one layer down): a pose is a
continuously re-asserted opinion about this instant. A pose from 200 ms ago
is worse than no pose — the client would blend toward the past. So: no TCP,
no retransmits, no queue. If the model is slower than the request rate,
intermediate requests are COALESCED — only the newest conditioning batch is
inferred, and the counter says how many were superseded.

THE MODEL SEAM: `MotionModel.infer(batch) -> poses` is the entire contract.
The bundled StubGaitModel is a deterministic procedural walk-cycle generator
— not a placeholder apology but the pipeline's Tier-0: it lets the whole
translation layer (features → IPC → blend → root-lock) light up and be
soak-tested before a MotionBricks-class checkpoint ever downloads. A real
model swaps in behind the same three-line interface.

WIRE (mirrors MotionController.h; struct sizes are the handshake):
  REQ  hdr  <IHf>            seq, pawn_count, dt                    (10 B)
  REQ  pawn <8s ffff BBBB>   id, speed, heading, turn, accel,
                             locomotion, gesture, flags, reserved   (28 B)
  RESP hdr  <IHBB>           seq, pawn_count, status, reserved       (8 B)
  RESP pawn <8sH> + f*n      id, n_floats, pose
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import math
import struct
import time
from dataclasses import dataclass, field

log = logging.getLogger("panopticon.motion")

REQ_HDR = "<IHf"
REQ_PAWN = "<8sffffBBBB"
RESP_HDR = "<IHBB"
REQ_HDR_SIZE = struct.calcsize(REQ_HDR)          # 10
REQ_PAWN_SIZE = struct.calcsize(REQ_PAWN)        # 28
RESP_HDR_SIZE = struct.calcsize(RESP_HDR)        # 8
assert (REQ_HDR_SIZE, REQ_PAWN_SIZE, RESP_HDR_SIZE) == (10, 28, 8), \
    "wire drifted from MotionController.h"

STATUS_OK = 0
STATUS_STUB = 1          # sidecar-degraded: procedural gait, not the model

LOCOMOTION = ("idle", "walk", "run", "arrive")
GESTURES = ("none", "reach_pickup", "hand_give", "use_operate",
            "cosign_press", "talk")


@dataclass(frozen=True)
class PawnConditioning:
    agent_id: bytes          # 8-byte compacted wire id, NUL-padded
    speed: float
    heading: float
    turn_rate: float
    accel: float
    locomotion: int
    gesture: int
    flags: int


def parse_request(data: bytes) -> tuple[int, float, list[PawnConditioning]] | None:
    """Strict, size-exact parse. Malformed → None (dropped, counted by the
    caller). The client is trusted software but an untrusted datagram."""
    if len(data) < REQ_HDR_SIZE:
        return None
    seq, count, dt = struct.unpack_from(REQ_HDR, data, 0)
    if len(data) != REQ_HDR_SIZE + count * REQ_PAWN_SIZE:
        return None
    pawns = []
    off = REQ_HDR_SIZE
    for _ in range(count):
        (aid, speed, heading, turn, accel,
         loco, gesture, flags, _res) = struct.unpack_from(REQ_PAWN, data, off)
        off += REQ_PAWN_SIZE
        if loco >= len(LOCOMOTION) or gesture >= len(GESTURES):
            return None
        pawns.append(PawnConditioning(aid, speed, heading, turn, accel,
                                      loco, gesture, flags))
    return seq, dt, pawns


def encode_response(seq: int, poses: list[tuple[bytes, list[float]]],
                    status: int) -> bytes:
    out = bytearray(struct.pack(RESP_HDR, seq & 0xFFFFFFFF,
                                len(poses), status, 0))
    for aid, floats in poses:
        out += struct.pack("<8sH", aid, len(floats))
        out += struct.pack(f"<{len(floats)}f", *floats)
    return bytes(out)


# ============================================================================
# The model seam
# ============================================================================

class StubGaitModel:
    """Deterministic procedural gait: per-pawn phase advanced by stride
    frequency ∝ speed, emitting a compact 24-float pose (12 joints × pitch/
    yaw pairs: legs swing in antiphase, arms counter-swing, torso bobs at 2×
    stride, head/hands modulate by gesture). Not beautiful — CORRECT: phase
    is continuous across calls, cadence tracks conditioning speed (the
    stride-warp contract), idle collapses to breathing sway, and identical
    call sequences produce identical poses (regression-testable)."""

    N_FLOATS = 24
    STRIDE_HZ_PER_SPEED = 0.9          # walk cadence per unit/s

    def __init__(self) -> None:
        self._phase: dict[bytes, float] = {}
        self.status = STATUS_STUB

    def infer(self, dt: float, batch: list[PawnConditioning]
              ) -> list[tuple[bytes, list[float]]]:
        out = []
        for p in batch:
            ph = self._phase.get(p.agent_id, 0.0)
            ph += dt * 2 * math.pi * max(0.25, p.speed) \
                * self.STRIDE_HZ_PER_SPEED
            self._phase[p.agent_id] = ph % (2 * math.pi * 1e6)
            amp = min(1.0, p.speed / 2.5)          # steering_speed nominal
            swing = math.sin(ph) * amp
            talk = 1.0 if p.gesture == 5 else 0.0
            reach = 1.0 if p.gesture in (1, 2, 3, 4) else 0.0
            pose = [
                swing * 0.6, -swing * 0.6,          # L/R hip pitch
                max(0.0, -swing) * 0.9,             # L knee
                max(0.0, swing) * 0.9,              # R knee
                -swing * 0.4 + reach * 0.8,         # L shoulder (+reach)
                swing * 0.4 + talk * 0.3 * math.sin(ph * 3),   # R shoulder
                reach * 0.6, talk * 0.2,            # elbows
                math.sin(ph * 2) * 0.05 * amp,      # torso bob
                p.turn_rate * 0.15,                 # torso lean into turns
                talk * 0.1 * math.sin(ph * 2.3),    # head nod (talking)
                0.02 * math.sin(ph * 0.5) * (1 - amp),  # idle sway
            ]
            pose += [0.0] * (self.N_FLOATS - len(pose))
            out.append((p.agent_id, pose))
        return out


def load_model(spec: str | None):
    """SEAM: `--model pkg.module:ClassName` → instantiated with .infer(dt,
    batch). A MotionBricks-class wrapper implements exactly that and sets
    .status = STATUS_OK. No spec → the stub."""
    if not spec:
        return StubGaitModel()
    mod_name, _, cls_name = spec.partition(":")
    module = __import__(mod_name, fromlist=[cls_name])
    return getattr(module, cls_name)()


# ============================================================================
# The service: latest-wins inference loop
# ============================================================================

@dataclass
class SidecarStats:
    received: int = 0
    malformed: int = 0
    stale: int = 0
    coalesced: int = 0
    inferred: int = 0
    model_failures: int = 0
    infer_ms: list[float] = field(default_factory=list)


class MotionSidecar(asyncio.DatagramProtocol):
    def __init__(self, model) -> None:
        self.model = model
        self.stats = SidecarStats()
        self._latest: tuple[int, float, list, tuple] | None = None
        self._kick = asyncio.Event()
        self._last_seq = 0
        self.transport: asyncio.DatagramTransport | None = None

    # ---- ingress: parse, seq-gate, coalesce --------------------------------
    def connection_made(self, transport) -> None:
        self.transport = transport

    def datagram_received(self, data: bytes, addr) -> None:
        self.stats.received += 1
        parsed = parse_request(data)
        if parsed is None:
            self.stats.malformed += 1
            return
        seq, dt, pawns = parsed
        if seq <= self._last_seq:
            self.stats.stale += 1                 # reordered/duplicate: drop
            return
        self._last_seq = seq
        if self._latest is not None:
            self.stats.coalesced += 1             # model busy: supersede
        self._latest = (seq, dt, pawns, addr)
        self._kick.set()

    # ---- the worker: one inference at a time, newest batch only ------------
    async def run_worker(self) -> None:
        while True:
            await self._kick.wait()
            self._kick.clear()
            job = self._latest
            self._latest = None
            if job is None:
                continue
            seq, dt, pawns, addr = job
            start = time.monotonic()
            try:
                # EXECUTOR, NOT INLINE — the finding the test suite caught:
                # a blocking infer() on the event loop also blocks
                # datagram_received, so requests pile up in the KERNEL socket
                # buffer and drain FIFO — latest-wins silently becomes the
                # backlog it exists to prevent. Off-loop inference keeps
                # ingress live: new batches land, coalesce, supersede.
                poses = await asyncio.get_running_loop().run_in_executor(
                    None, self.model.infer, dt, pawns)
                status = getattr(self.model, "status", STATUS_OK)
            except Exception:
                # FAIL-OPEN BY SILENCE: no response is the protocol's error
                # signal — the client watchdog reads absence and glides. An
                # error frame would be a second code path to get wrong.
                self.stats.model_failures += 1
                log.exception("model.infer failed — responding with silence")
                continue
            self.stats.inferred += 1
            self.stats.infer_ms.append((time.monotonic() - start) * 1000)
            if self.transport is not None:
                self.transport.sendto(encode_response(seq, poses, status),
                                      addr)


async def amain(args: argparse.Namespace) -> None:
    model = load_model(args.model)
    loop = asyncio.get_running_loop()
    transport, protocol = await loop.create_datagram_endpoint(
        lambda: MotionSidecar(model),
        local_addr=(args.host, args.port))
    log.info("motion sidecar up on %s:%d (model=%s, %s)", args.host,
             args.port, type(model).__name__,
             "STUB GAIT" if getattr(model, "status", 0) else "full model")
    worker = asyncio.create_task(protocol.run_worker())
    try:
        while True:
            await asyncio.sleep(30)
            s = protocol.stats
            avg = (sum(s.infer_ms[-100:]) / len(s.infer_ms[-100:])
                   if s.infer_ms else 0.0)
            log.info("recv=%d inferred=%d coalesced=%d stale=%d "
                     "malformed=%d failures=%d infer≈%.1fms",
                     s.received, s.inferred, s.coalesced, s.stale,
                     s.malformed, s.model_failures, avg)
    finally:
        worker.cancel()
        transport.close()


def main() -> None:
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s MOTION %(message)s")
    p = argparse.ArgumentParser(description="Panopticon motion sidecar")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=17555)
    p.add_argument("--model", default=None,
                   help="pkg.module:ClassName with .infer(dt, batch)")
    asyncio.run(amain(p.parse_args()))


if __name__ == "__main__":
    main()
