// ============================================================================
// UPanopticonCodex — implementation
// glasshouse/PanopticonCodex.cpp
//
// Uses the engine SQLiteCore plugin's stable API surface: FSQLiteDatabase
// (Open/ReadOnly, Execute, PrepareStatement), FSQLitePreparedStatement
// (SetBindingValueByIndex, Step, GetColumnValueByIndex, Reset). Column
// order below matches local_exporter.SCHEMA exactly; if the exporter's
// schema ever changes, bump bundle_version in the manifest and this file
// together — the pair is one contract.
// ============================================================================

#include "PanopticonCodex.h"

DEFINE_LOG_CATEGORY_STATIC(LogCodex, Log, All);

static constexpr int64 PANO_APPLICATION_ID = 0x50414E4F;   // 'PANO'

// ---------------------------------------------------------------------------
// The wire-id mirror. The detail that matters: LAST 8 alphanumerics — the
// discriminating tail — matching entities.compact_wire_id character for
// character. ("agent_000" → "agent000"; "the_grand_ledger_01" → "ledger01".)
// ---------------------------------------------------------------------------
FString UPanopticonCodex::CompactId(const FString& ServerId)
{
    FString Stripped;
    Stripped.Reserve(ServerId.Len());
    for (TCHAR C : ServerId)
    {
        if (FChar::IsAlnum(C))
        {
            Stripped.AppendChar(C);
        }
    }
    return Stripped.Len() > 8 ? Stripped.Right(8) : Stripped;
}

// ---------------------------------------------------------------------------
// Open: file → ReadOnly → application_id → tables → wire bridge → prepare.
// Every gate logs its reason and leaves the subsystem cleanly closed.
// ---------------------------------------------------------------------------
bool UPanopticonCodex::OpenBundle(const FString& BundleDir)
{
    if (bOpen) { Deinitialize(); }

    const FString DbPath = BundleDir / TEXT("world.db");
    if (!FPaths::FileExists(DbPath))
    {
        UE_LOG(LogCodex, Error, TEXT("no world.db in %s"), *BundleDir);
        return false;
    }
    if (!Db.Open(*DbPath, ESQLiteDatabaseOpenMode::ReadOnly))
    {
        UE_LOG(LogCodex, Error, TEXT("open failed: %s"),
               *Db.GetLastError());
        return false;
    }
    if (!VerifyApplicationId())
    {
        UE_LOG(LogCodex, Error,
               TEXT("application_id != 'PANO' — not a Panopticon world; "
                    TEXT("refusing tampered/foreign database")));
        Db.Close();
        return false;
    }
    for (const TCHAR* Table : { TEXT("agents"), TEXT("beliefs"),
                                TEXT("memories"), TEXT("derivations"),
                                TEXT("relationships") })
    {
        FSQLitePreparedStatement Probe(
            Db, *FString::Printf(TEXT("SELECT 1 FROM %s LIMIT 1"), Table));
        if (!Probe.IsValid())
        {
            UE_LOG(LogCodex, Error, TEXT("schema missing table %s"), Table);
            Db.Close();
            return false;
        }
    }
    if (!BuildWireBridge())
    {
        Db.Close();
        return false;
    }

    StmtBeliefs = FSQLitePreparedStatement(Db, TEXT(
        "SELECT text, importance, updated_at FROM beliefs "
        "WHERE agent_id = ?1 ORDER BY importance DESC"));
    StmtRelations = FSQLitePreparedStatement(Db, TEXT(
        "SELECT other_id, affinity, last_reason FROM relationships "
        "WHERE agent_id = ?1 ORDER BY affinity DESC"));
    StmtLineage = FSQLitePreparedStatement(Db, TEXT(
        "SELECT s.id, s.summary, s.t, s.location "
        "FROM derivations d JOIN memories s ON s.id = d.source_id "
        "WHERE d.consolidated_id = ?1 ORDER BY s.t"));
    StmtLifeStory = FSQLitePreparedStatement(Db, TEXT(
        "SELECT id, summary, t, location, consolidated, "
        "       archived_at, consolidated_into "
        "FROM memories WHERE agent_id = ?1 ORDER BY t"));
    if (!StmtBeliefs.IsValid() || !StmtRelations.IsValid()
        || !StmtLineage.IsValid() || !StmtLifeStory.IsValid())
    {
        UE_LOG(LogCodex, Error, TEXT("statement preparation failed"));
        Db.Close();
        return false;
    }

    bOpen = true;
    UE_LOG(LogCodex, Log, TEXT("codex open: %d agents, wire bridge built"),
           AgentIds.Num());
    return true;
}

bool UPanopticonCodex::VerifyApplicationId()
{
    int64 AppId = 0;
    FSQLitePreparedStatement Pragma(Db, TEXT("PRAGMA application_id"));
    if (!Pragma.IsValid()
        || Pragma.Step() != ESQLitePreparedStatementStepResult::Row
        || !Pragma.GetColumnValueByIndex(0, AppId))
    {
        return false;
    }
    return AppId == PANO_APPLICATION_ID;
}

bool UPanopticonCodex::BuildWireBridge()
{
    WireToServer.Empty();
    AgentIds.Empty();
    FSQLitePreparedStatement All(Db, TEXT("SELECT id FROM agents"));
    while (All.Step() == ESQLitePreparedStatementStepResult::Row)
    {
        FString ServerId;
        All.GetColumnValueByIndex(0, ServerId);
        const FString Wire = CompactId(ServerId);
        if (const FString* Clash = WireToServer.Find(Wire))
        {
            // Same abort the broadcaster registry performs at startup:
            // an ambiguous namespace serves nobody the truth.
            UE_LOG(LogCodex, Error,
                   TEXT("wire-id collision: '%s' ← '%s' and '%s'"),
                   *Wire, **Clash, *ServerId);
            return false;
        }
        WireToServer.Add(Wire, ServerId);
        AgentIds.Add(ServerId);
    }
    return true;
}

FString UPanopticonCodex::ResolveWireId(const FString& WireId) const
{
    // Accept either namespace: a raw server id passes through untouched,
    // so UI code holding roster ids and pawn code holding wire ids call
    // the same four functions.
    if (const FString* Server = WireToServer.Find(WireId))
    {
        return *Server;
    }
    return AgentIds.Contains(WireId) ? WireId : FString();
}

TArray<FString> UPanopticonCodex::GetAllAgentIds() const { return AgentIds; }

// ---------------------------------------------------------------------------
// The four panels.
// ---------------------------------------------------------------------------
TArray<FCodexBelief> UPanopticonCodex::GetBeliefs(const FString& WireId)
{
    TArray<FCodexBelief> Out;
    const FString Agent = ResolveWireId(WireId);
    if (!bOpen || Agent.IsEmpty()) { return Out; }

    StmtBeliefs.Reset();
    StmtBeliefs.SetBindingValueByIndex(1, Agent);
    while (StmtBeliefs.Step() == ESQLitePreparedStatementStepResult::Row)
    {
        FCodexBelief B;
        double Imp = 0, At = 0;
        StmtBeliefs.GetColumnValueByIndex(0, B.Text);
        StmtBeliefs.GetColumnValueByIndex(1, Imp);
        StmtBeliefs.GetColumnValueByIndex(2, At);
        B.Importance = float(Imp);
        B.UpdatedAt  = float(At);
        Out.Add(MoveTemp(B));
    }
    return Out;
}

TArray<FCodexRelation> UPanopticonCodex::GetRelations(const FString& WireId)
{
    TArray<FCodexRelation> Out;
    const FString Agent = ResolveWireId(WireId);
    if (!bOpen || Agent.IsEmpty()) { return Out; }

    StmtRelations.Reset();
    StmtRelations.SetBindingValueByIndex(1, Agent);
    while (StmtRelations.Step() == ESQLitePreparedStatementStepResult::Row)
    {
        FCodexRelation R;
        double Aff = 0;
        StmtRelations.GetColumnValueByIndex(0, R.OtherAgentId);
        StmtRelations.GetColumnValueByIndex(1, Aff);
        StmtRelations.GetColumnValueByIndex(2, R.LastReason);
        R.Affinity   = float(Aff);
        R.OtherWireId = CompactId(R.OtherAgentId);   // clickable cross-link
        Out.Add(MoveTemp(R));
    }
    return Out;
}

TArray<FCodexMemory> UPanopticonCodex::GetLineage(
    const FString& ConsolidatedMemoryId)
{
    TArray<FCodexMemory> Out;
    if (!bOpen) { return Out; }

    StmtLineage.Reset();
    StmtLineage.SetBindingValueByIndex(1, ConsolidatedMemoryId);
    while (StmtLineage.Step() == ESQLitePreparedStatementStepResult::Row)
    {
        FCodexMemory M;
        double T = 0;
        StmtLineage.GetColumnValueByIndex(0, M.Id);
        StmtLineage.GetColumnValueByIndex(1, M.Summary);
        StmtLineage.GetColumnValueByIndex(2, T);
        StmtLineage.GetColumnValueByIndex(3, M.Location);
        M.T = float(T);
        M.bArchived = true;      // lineage sources are tombstoned by defn
        Out.Add(MoveTemp(M));
    }
    return Out;
}

TArray<FCodexMemory> UPanopticonCodex::GetLifeStory(const FString& WireId)
{
    TArray<FCodexMemory> Out;
    const FString Agent = ResolveWireId(WireId);
    if (!bOpen || Agent.IsEmpty()) { return Out; }

    StmtLifeStory.Reset();
    StmtLifeStory.SetBindingValueByIndex(1, Agent);
    while (StmtLifeStory.Step() == ESQLitePreparedStatementStepResult::Row)
    {
        FCodexMemory M;
        double T = 0, ArchivedAt = 0;
        int64 Consolidated = 0;
        StmtLifeStory.GetColumnValueByIndex(0, M.Id);
        StmtLifeStory.GetColumnValueByIndex(1, M.Summary);
        StmtLifeStory.GetColumnValueByIndex(2, T);
        StmtLifeStory.GetColumnValueByIndex(3, M.Location);
        StmtLifeStory.GetColumnValueByIndex(4, Consolidated);
        // archived_at is NULL for living memories: NULL reads report
        // false and leave the default → bArchived stays false. Exactly
        // the faded/solid split the UI renders.
        M.bArchived = StmtLifeStory.GetColumnValueByIndex(5, ArchivedAt)
                      && ArchivedAt > 0;
        StmtLifeStory.GetColumnValueByIndex(6, M.ConsolidatedInto);
        M.T = float(T);
        M.bConsolidated = Consolidated != 0;
        Out.Add(MoveTemp(M));
    }
    return Out;
}

void UPanopticonCodex::Deinitialize()
{
    StmtBeliefs.Destroy();
    StmtRelations.Destroy();
    StmtLineage.Destroy();
    StmtLifeStory.Destroy();
    if (Db.IsValid()) { Db.Close(); }
    WireToServer.Empty();
    AgentIds.Empty();
    bOpen = false;
    Super::Deinitialize();
}
