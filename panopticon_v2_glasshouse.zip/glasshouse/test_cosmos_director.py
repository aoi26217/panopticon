"""Tier 4 broadcast pipeline verification — production-packed frames in,
publish-directory contents out. The gate logic is the deliverable."""
import importlib.util, json, pathlib, struct, sys, tempfile, types
spec = importlib.util.spec_from_file_location(
    "cosmos_director", pathlib.Path("glasshouse/cosmos_director.py"))
cd = importlib.util.module_from_spec(spec)
sys.modules["cosmos_director"] = cd
spec.loader.exec_module(cd)
import broadcaster as bc
import entities as en

def frame(tick, agents):
    out = bytearray(struct.pack(bc.HEADER_FMT, tick, len(agents)))
    for aid, x, y in agents:
        out += struct.pack(bc.AGENT_FMT, bc.compact_wire_id(aid),
                           x, y, 1.0, 0.0, bc.FLAG_SPEAKING)
    return bytes(out)

def feed(d, n_ticks=101):
    for t in range(1, n_ticks + 1):
        d.on_data(types.SimpleNamespace(
            data=frame(t, [("agent_000", 10.0 + t * 0.05, 20.0)]),
            topic=bc.DATA_TOPIC))
    d.on_data(types.SimpleNamespace(
        data=en.encode_entity_deltas(n_ticks, [en.Entity(
            id="relic_01", kind="relic", x=5, y=5, version=3)]),
        topic=en.ENTITY_TOPIC))

def mkdir():
    return pathlib.Path(tempfile.mkdtemp())

# 1. HAPPY PATH: tagged, verified, published with a truthful sidecar
out = mkdir()
d = cd.BroadcastDirector(cd.StubCosmos(0.0), cd.StubWatermark(),
                         cd.StubDetector(0.97), out)
feed(d); assert d.window_ready()
clip = d.produce()
assert clip and clip.exists() and d.stats.clips_published == 1
prov = json.loads(clip.with_suffix(clip.suffix + ".provenance.json"
                                   ).read_text())
assert prov["tag"] == cd.DRAMATIZATION_TAG and prov["synthetic_score"] == 0.97
assert prov["sha256"] and prov["drift_worst_units"] <= 1.5
assert b"TAG:DRAMATIZATION" in clip.read_bytes()
assert not any((out / "_staging").iterdir())
print("PASS publish: tagged clip + provenance sidecar (tag, score, drift, "
      "hash); staging empty")

# 2. DRIFT GUARD: 2.0-unit hallucination → rejected + re-ground counted
out = mkdir()
d = cd.BroadcastDirector(cd.StubCosmos(inject_drift=2.0), cd.StubWatermark(),
                         cd.StubDetector(0.97), out)
feed(d)
assert d.produce() is None
assert d.stats.drift_rejects == 1 and d.stats.regrounds == 1
assert d.stats.clips_published == 0 and not list(out.glob("clip_*"))
# and within-limit drift still airs (drift is a limit, not a demand for zero)
d2 = cd.BroadcastDirector(cd.StubCosmos(inject_drift=1.0), cd.StubWatermark(),
                          cd.StubDetector(0.97), mkdir())
feed(d2); assert d2.produce() is not None
print("PASS drift guard: 2.0u lie rejected + re-grounded; 1.0u tolerance "
      "airs — truth is a limit, not vanity")

# 3. FAIL-CLOSED (a): detector NIM down → BLOCKED, nothing published
out = mkdir()
d = cd.BroadcastDirector(cd.StubCosmos(0.0), cd.StubWatermark(),
                         cd.StubDetector(fixed=None), out)
feed(d)
assert d.produce() is None
assert d.stats.provenance_blocks == 1 and d.stats.detector_failures == 1
assert not list(out.glob("clip_*")) and not any((out/"_staging").iterdir())
print("PASS fail-closed: detector unreachable → clip blocked and destroyed "
      "(the inversion: liveness fails open, publishing fails closed)")

# 4. FAIL-CLOSED (b): footage too plausible (score 0.3 < 0.8) → BLOCKED
out = mkdir()
d = cd.BroadcastDirector(cd.StubCosmos(0.0), cd.StubWatermark(),
                         cd.StubDetector(0.30), out)
feed(d)
assert d.produce() is None and d.stats.provenance_blocks == 1
print("PASS fail-closed: clip scoring as plausibly-real blocked — "
      "detectably-synthetic is a RELEASE REQUIREMENT")

# 5. FAIL-CLOSED (c): watermark that silently no-ops → verified, BLOCKED
class LyingWatermark(cd.StubWatermark):
    def apply(self, clip, tag): return clip        # claims success, does 0
out = mkdir()
d = cd.BroadcastDirector(cd.StubCosmos(0.0), LyingWatermark(),
                         cd.StubDetector(0.97), out)
feed(d)
assert d.produce() is None and d.stats.provenance_blocks == 1
print("PASS fail-closed: no-op watermark caught by verify-don't-trust "
      "readback")

# 6. conditioning fidelity: window payload mirrors the wire
out = mkdir()
d = cd.BroadcastDirector(cd.StubCosmos(0.0), cd.StubWatermark(),
                         cd.StubDetector(0.97), out)
feed(d)
w = d.cut_window()
pay = w.to_prompt_payload()
assert pay["ticks"] == [1, 101] and "agent000" in pay["agents"]
assert pay["agents"]["agent000"][0] == {"t": 1, "x": 10.05, "y": 20.0,
                                        "speaking": True}
assert pay["entities"][0]["kind"] == "relic" and w.camera == "plaza_wide"
print("PASS conditioning: window payload mirrors production wire truth")
print("\nALL TIER 4 BROADCAST TESTS PASSED")
