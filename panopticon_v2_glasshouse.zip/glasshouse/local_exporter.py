"""
Project Panopticon — Tier 5: The Local Exporter (Bake Daemon)
==============================================================
glasshouse/local_exporter.py

Bakes a live simulation session into a standalone playback bundle a
consumer PC can run without SGLang, Neo4j, Qdrant, or the SFU:

    bundle/
      world.db          consolidated belief graph → read-only SQLite
      entities.json     final reliable-plane truth (from a live keyframe)
      session.usda      the Tier 3 --record stage, flushed and validated
      manifest.json     counts, tick range, SHA-256 per artifact

    python3 local_exporter.py --out bundle/ \\
        --neo4j-uri bolt://host:7687 --neo4j-password ... \\
        --livekit-url ws://host:7880 --livekit-api-key K --livekit-api-secret S \\
        --usd-stage /workspace/session.usda [--usd-observer-pid 12345]

ZERO DISRUPTION, BY MECHANISM (not by politeness):
  * Neo4j: every query runs in READ-mode sessions (execute_read /
    default_access_mode=READ). The single-writer invariant governs
    mutations; reads were always unrestricted (README §2.1) and run as
    concurrent read transactions the writer never waits on. Extraction is
    additionally paced (--batch pause) so a huge graph cannot monopolize
    the DB's page cache mid-show.
  * Entities: the exporter joins the room as one more SUBSCRIBE-ONLY
    participant (can_publish=False — the Tier 3 grant) and simply waits
    for the reliable plane's 10 s late-joiner keyframe. That keyframe
    exists precisely for consumers who arrive mid-history; the exporter IS
    a late joiner. The engine and SFU never learn it was there.
  * USD observer: a cooperating process, not a shared one. Graceful
    termination = SIGINT (its finally-block saves the stage), then a
    QUIESCENCE WAIT — the stage file's (size, mtime) must hold still
    across consecutive polls AND reopen as a valid stage with an end
    timecode — before it is copied into the bundle. We do not trust a
    signal was enough; we verify the flush landed.

The graph goes to SQLite because the game needs a query engine, not a
graph server: the codex UI's questions ("what does agent007 believe",
"who does she resent", "which memories became this belief") are indexed
lookups. Marked read-only three ways: PRAGMA query_only documented for
consumers, file chmod 0444, and application_id stamped so the UE plugin
can refuse a writable open.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import logging
import os
import shutil
import signal
import sqlite3
import sys
import time
from pathlib import Path
from typing import Any, Protocol

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

log = logging.getLogger("panopticon.export")
APPLICATION_ID = 0x50414E4F                      # 'PANO'

# ---------------------------------------------------------------------------
# Graph extraction — Cypher mirrors clients._STATEMENTS labels exactly.
# ---------------------------------------------------------------------------

EXPORT_QUERIES: dict[str, str] = {
    "agents": "MATCH (a:Agent) RETURN a.id AS id ORDER BY id",
    "beliefs": """
        MATCH (a:Agent)-[:HOLDS]->(b:Belief)
        RETURN a.id AS agent_id, b.text AS text,
               b.importance AS importance, b.updated_at AS updated_at
        ORDER BY agent_id, importance DESC""",
    "memories": """
        MATCH (m:Memory)
        OPTIONAL MATCH (a:Agent)-[:REMEMBERS|ARCHIVED_REMEMBERS]->(m)
        OPTIONAL MATCH (m)-[:AT]->(l:Location)
        RETURN m.id AS id, a.id AS agent_id, m.summary AS summary,
               m.t AS t, l.id AS location,
               m:Consolidated AS consolidated,
               m.archived_at AS archived_at,
               m.consolidated_into AS consolidated_into,
               m.source_count AS source_count""",
    "derivations": """
        MATCH (m:Memory)-[:DERIVED_FROM]->(s:Memory)
        RETURN m.id AS consolidated_id, s.id AS source_id""",
    "relationships": """
        MATCH (a:Agent)-[r:RELATES_TO]->(b:Agent)
        RETURN a.id AS agent_id, b.id AS other_id, r.affinity AS affinity,
               r.last_reason AS last_reason, r.updated_at AS updated_at""",
    "observations": """
        MATCH (a:Agent)-[r:OBSERVED]->(l:Location)
        RETURN a.id AS agent_id, l.id AS location, r.at AS at,
               r.summary AS summary""",
}

SCHEMA = """
CREATE TABLE agents (id TEXT PRIMARY KEY);
CREATE TABLE beliefs (agent_id TEXT, text TEXT, importance REAL,
                      updated_at REAL);
CREATE TABLE memories (id TEXT PRIMARY KEY, agent_id TEXT, summary TEXT,
                       t REAL, location TEXT, consolidated INTEGER,
                       archived_at REAL, consolidated_into TEXT,
                       source_count INTEGER);
CREATE TABLE derivations (consolidated_id TEXT, source_id TEXT);
CREATE TABLE relationships (agent_id TEXT, other_id TEXT, affinity REAL,
                            last_reason TEXT, updated_at REAL);
CREATE TABLE observations (agent_id TEXT, location TEXT, at REAL,
                           summary TEXT);
CREATE INDEX ix_beliefs_agent ON beliefs(agent_id);
CREATE INDEX ix_memories_agent ON memories(agent_id, archived_at);
CREATE INDEX ix_rel_agent ON relationships(agent_id);
CREATE INDEX ix_deriv ON derivations(consolidated_id);
"""


class GraphSource(Protocol):                     # seam: prod Neo4j / test fake
    async def rows(self, table: str, query: str) -> list[dict[str, Any]]: ...
    async def close(self) -> None: ...


class Neo4jExportSource:
    """READ-mode sessions only. Cannot mutate: contains no write call and
    opens no write transaction — purity by absence of capability."""
    def __init__(self, uri: str, password: str, user: str = "neo4j") -> None:
        import neo4j
        self._driver = neo4j.AsyncGraphDatabase.driver(uri,
                                                       auth=(user, password))
        self._neo4j = neo4j

    async def rows(self, table: str, query: str) -> list[dict[str, Any]]:
        async with self._driver.session(
                default_access_mode=self._neo4j.READ_ACCESS) as sess:
            result = await sess.run(query)
            return [dict(rec) async for rec in result]

    async def close(self) -> None:
        await self._driver.close()


async def export_graph(source: GraphSource, db_path: Path,
                       pause_s: float = 0.05) -> dict[str, int]:
    if db_path.exists():
        db_path.unlink()
    conn = sqlite3.connect(db_path)
    conn.executescript(SCHEMA)
    conn.execute(f"PRAGMA application_id = {APPLICATION_ID}")
    counts: dict[str, int] = {}
    for table, query in EXPORT_QUERIES.items():
        rows = await source.rows(table, query)
        if rows:
            cols = list(rows[0].keys())
            conn.executemany(
                f"INSERT INTO {table} ({','.join(cols)}) "
                f"VALUES ({','.join('?' * len(cols))})",
                [tuple(bool(r[c]) if isinstance(r[c], bool) else r[c]
                       for c in cols) for r in rows])
        counts[table] = len(rows)
        conn.commit()
        await asyncio.sleep(pause_s)             # pace: never monopolize
    conn.execute("PRAGMA query_only = ON")       # documented consumer mode
    conn.close()
    os.chmod(db_path, 0o444)                     # read-only artifact
    return counts


# ---------------------------------------------------------------------------
# Entity snapshot — one more late joiner on the reliable plane.
# ---------------------------------------------------------------------------

async def capture_entities(livekit_url: str, key: str, secret: str,
                           room_name: str, timeout_s: float = 15.0) -> dict:
    """Join subscribe-only, wait for the 10 s keyframe (built for exactly
    this), return {entity_id: record}. Deltas that arrive first are kept —
    keyframe + deltas converge to the same truth by version watermark."""
    from livekit import api, rtc
    from entities import ENTITY_TOPIC, decode_entity_deltas

    captured: dict[str, dict] = {}
    got_any = asyncio.Event()

    def on_data(packet) -> None:
        try:
            if getattr(packet, "topic", "") == ENTITY_TOPIC:
                _t, recs = decode_entity_deltas(bytes(packet.data))
                for r in recs:
                    prev = captured.get(r["id"])
                    if prev is None or r["version"] >= prev["version"]:
                        captured[r["id"]] = r
                if recs:
                    got_any.set()
        except Exception:
            log.exception("entity packet dropped (fail-open)")

    token = (api.AccessToken(key, secret)
             .with_identity("panopticon-exporter")
             .with_grants(api.VideoGrants(
                 room_join=True, room=room_name, can_subscribe=True,
                 can_publish=False, can_publish_data=False))    # PURITY
             .to_jwt())
    room = rtc.Room()
    room.on("data_received", on_data)
    await room.connect(livekit_url, token)
    try:
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            await asyncio.sleep(0.25)            # keyframe interlace ≤ 10 s
            if got_any.is_set() and time.monotonic() > deadline - 3.0:
                break                            # keyframe window covered
    finally:
        await room.disconnect()
    return captured


# ---------------------------------------------------------------------------
# Observer sync — signal, then VERIFY the flush landed.
# ---------------------------------------------------------------------------

def flush_usd_observer(stage_path: Path, observer_pid: int | None,
                       timeout_s: float = 20.0,
                       poll_s: float = 0.5) -> dict:
    if observer_pid is not None:
        try:
            os.kill(observer_pid, signal.SIGINT)  # its finally-block saves
            log.info("SIGINT → usd_observer pid %d", observer_pid)
        except ProcessLookupError:
            log.warning("observer pid %d already gone — validating file",
                        observer_pid)
    deadline = time.monotonic() + timeout_s
    last: tuple[int, float] | None = None
    while time.monotonic() < deadline:
        if stage_path.exists():
            st = stage_path.stat()
            cur = (st.st_size, st.st_mtime)
            if cur == last:                       # quiescent across a poll
                break
            last = cur
        time.sleep(poll_s)
    else:
        raise TimeoutError(f"stage never quiesced: {stage_path}")
    from pxr import Usd                           # validate, don't assume
    stage = Usd.Stage.Open(str(stage_path))
    if stage is None:
        raise RuntimeError(f"flushed stage failed to open: {stage_path}")
    end = stage.GetEndTimeCode()
    agents = [p for p in stage.Traverse()
              if str(p.GetPath()).startswith("/World/Agents/")
              and p.GetTypeName() == "Xform"]
    if end <= 0 or not agents:
        raise RuntimeError("stage flushed but empty — no session to bake")
    return {"end_time_code": end, "timecodes_per_second":
            stage.GetTimeCodesPerSecond(), "agent_prims": len(agents)}


# ---------------------------------------------------------------------------
# The bake
# ---------------------------------------------------------------------------

def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


async def bake(args, graph_source: GraphSource | None = None,
               entities: dict | None = None) -> Path:
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    # 1. observer flush FIRST — freezes the visual record's end while the
    #    graph export (slowest step) runs against a world that keeps living.
    stage_info = flush_usd_observer(Path(args.usd_stage),
                                    args.usd_observer_pid)
    shutil.copy2(args.usd_stage, out / "session.usda")

    # 2. graph → sqlite (read-only sessions; paced)
    src = graph_source or Neo4jExportSource(args.neo4j_uri,
                                            args.neo4j_password)
    try:
        counts = await export_graph(src, out / "world.db")
    finally:
        await src.close()

    # 3. entities: injected (tests) or captured live as a late joiner
    if entities is None:
        entities = await capture_entities(args.livekit_url,
                                          args.livekit_api_key,
                                          args.livekit_api_secret, args.room)
    (out / "entities.json").write_text(json.dumps(
        {"captured_at": time.time(), "entities": entities}, indent=1))

    # 4. manifest — the bundle's chain of custody
    manifest = {
        "bundle_version": 1,
        "stage": stage_info,
        "graph_counts": counts,
        "entity_count": len(entities),
        "artifacts": {name: {"sha256": _sha(out / name),
                             "bytes": (out / name).stat().st_size}
                      for name in ("session.usda", "world.db",
                                   "entities.json")},
    }
    (out / "manifest.json").write_text(json.dumps(manifest, indent=1))
    log.info("baked %s: %s", out, {k: v for k, v in manifest.items()
                                   if k != "artifacts"})
    return out


def main() -> None:
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s EXPORT %(message)s")
    p = argparse.ArgumentParser(description="Panopticon bake daemon")
    p.add_argument("--out", required=True)
    p.add_argument("--neo4j-uri", required=True)
    p.add_argument("--neo4j-password", required=True)
    p.add_argument("--livekit-url", required=True)
    p.add_argument("--livekit-api-key", required=True)
    p.add_argument("--livekit-api-secret", required=True)
    p.add_argument("--room", default="panopticon")
    p.add_argument("--usd-stage", required=True)
    p.add_argument("--usd-observer-pid", type=int, default=None)
    asyncio.run(bake(p.parse_args()))


if __name__ == "__main__":
    main()
