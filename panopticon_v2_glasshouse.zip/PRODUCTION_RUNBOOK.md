# PROJECT PANOPTICON — Master Production Runbook & Operational Roadmap

**The workflow:** short, targeted cloud shoots on a RunPod RTX 4090 →
bake to a local bundle → standalone, zero-LLM-cost UE5 game.
**The invariants, restated once and assumed everywhere below:** the
heartbeat never bends; simulation fails open; bundles and publishing fail
closed; the shipped game performs zero live LLM compute.

This document was produced from a top-to-bottom pipeline review. Five
genuine gaps were found; each is corrected inline in a `⚠ GAP` box and
indexed in §6. Read the gap boxes even if you skim everything else — two
of them (§1-G1, §2-G2) would have silently ruined a paid shoot.

---

## Phase 0 — Local Pre-Flight (before renting anything)

Do these on your desk; every minute here is a billed minute saved later.

**0.1 — Author the lore seed file** (`seeds.json`, schema in §1).

**0.2 — Author the entity roster** (`entities_seed.json`, schema in §1.3).

**0.3 — THE ID PRE-FLIGHT.** Every agent, character, and entity id must
be unique under wire compaction (strip non-alphanumerics, keep the LAST
8). Collisions abort the broadcaster at startup — on the pod, on the
clock. Check locally:

```python
python3 - <<'EOF'
import json, entities
ids = [a["id"] for a in json.load(open("seeds.json"))["characters"]]
ids += [e["id"] for e in json.load(open("entities_seed.json"))]
ids += ["magnus"]
wire = [entities.compact_wire_id(i) for i in ids]
dupes = {w for w in wire if wire.count(w) > 1}
assert not dupes, f"WIRE COLLISION: {dupes} — rename before shooting"
print(f"OK: {len(ids)} ids, all unique under last-8 compaction")
EOF
```

Naming rule of thumb: make the **tail** distinctive (`aldo_merchant`,
`aldo_guard`), never the head (`merchant_aldo`, `guard_aldo` — safe here,
but `character_aldo_1` / `narrative_aldo_1` both end `ntaldo1`-style and
will bite).

**0.4 — Decide the shoot length** (see §2-G2). Recommended: **≤ 15
minutes per shoot**, multiple shoots over one pod session.

---

## Phase 1 — Lore Pre-Seeding (Neo4j + Qdrant, on the pod, pre-ignition)

Seeding happens **after services are healthy, before the orchestrator
ignites**. Pre-ignition, the single-writer invariant is not in play (no
writer exists yet), so direct writes are legal. If you ever seed
mid-simulation, mutations must go through `GraphWriteQueue` — but don't:
pre-ignition seeding is simpler and sufficient.

> **⚠ GAP 1-G1 — THE VECTOR-FIRST TRAP (the big one).** Retrieval is
> vector-first: `MemoryService.retrieve_context` searches **Qdrant**,
> then expands the hits 1-hop in Neo4j (`_FETCH_MEMORIES`). A memory
> seeded into Neo4j alone is **never retrieved — it does not exist to the
> agents.** Every seeded memory must be dual-written: embedded (by the
> same bge-m3 the engine uses) into Qdrant with point-id == `Memory.id`,
> AND written to the graph. The correct tool already exists:
> `MemoryService.store_memory` performs the vector-first dual write with
> the right ids, the right payload, and the abort-before-graph asymmetry.
> **Seed memories through it; never hand-write Memory nodes.**

**1.1 — Seed schema** (`seeds.json`):

```json
{
  "locations":  [ {"id": "fountain"}, {"id": "north_gate"} ],
  "characters": [ {"id": "aldo_merchant",
                   "beliefs": [ {"text": "the gate tax is theft",
                                 "importance": 0.9} ],
                   "memories": [ "I arrived in the plaza three winters ago.",
                                 "The vault has never opened for one person." ]} ],
  "world_news": [ {"agents": "all",
                   "text": "News reached the plaza: the river market closed."} ]
}
```

Schema requirements, matched to what the daemons actually read:
* **Beliefs** → `(a:Agent {id})-[:HOLDS]->(b:Belief {agent_id, text})`
  with `b.importance`, `b.updated_at`. Read by `fetch_beliefs` → the Q3
  goal daemon builds motivation from them, and Q2 consolidation extends
  them. Direct Cypher is fine (matches `clients._STATEMENTS["belief"]`).
* **Memories** → via `store_memory` only (G1). These are what the Q2/Q1
  retrieval pulls at ignition; `world_news` items fan out one memory per
  agent — cheap, and every agent "remembers hearing" your backstory.
* **Locations** → `MERGE (l:Location {id})`. Referenced by the `AT` edges
  `store_memory` creates when a location is mentioned.

**1.2 — The seeder** (run on the pod; uses production clients end-to-end):

```bash
docker compose -f docker-compose-runpod.yml run --rm orchestrator \
  python3 - <<'EOF'
import asyncio, json, sys, uuid
from clients import RealNeo4jGraphClient
from memory import MemoryService, RealEmbeddingClient, RealQdrantClient

async def main():
    seeds = json.load(open("/app/maps/seeds.json"))   # mount next to plaza
    graph = RealNeo4jGraphClient("bolt://neo4j:7687", password="...")
    svc = MemoryService(RealEmbeddingClient("http://embeddings:8080"),
                        RealQdrantClient("http://qdrant:6333"), graph)
    await svc.connect()
    n = 0
    for ch in seeds["characters"]:
        for m in ch.get("memories", []):
            await svc.store_memory(ch["id"], m); n += 1
    agents = [c["id"] for c in seeds["characters"]] \
             + [f"agent_{i:03d}" for i in range(50)]
    for item in seeds.get("world_news", []):
        targets = agents if item["agents"] == "all" else item["agents"]
        for a in targets:
            await svc.store_memory(a, item["text"]); n += 1
    # beliefs + locations: direct, pre-ignition-legal
    async with graph._driver.session() as s:            # noqa: seed-only
        for loc in seeds.get("locations", []):
            await s.run("MERGE (:Location {id: $id})", id=loc["id"])
        for ch in seeds["characters"]:
            for b in ch.get("beliefs", []):
                await s.run("""MERGE (a:Agent {id:$a})
                    MERGE (b:Belief {agent_id:$a, text:$t})
                    SET b.importance=$i, b.updated_at=0.0
                    MERGE (a)-[:HOLDS]->(b)""",
                    a=ch["id"], t=b["text"], i=b["importance"])
    print(f"seeded {n} memories (dual-written) + beliefs + locations")
asyncio.run(main())
EOF
```

Verification before ignition (non-negotiable): a Qdrant scroll must show
your seeded points, and `MATCH (b:Belief) RETURN count(b)` must match
your seed file. If Qdrant is empty, G1 got you — stop and fix.

**1.3 — Custom entities** (`entities_seed.json`) — the reliable-plane
contract, field by field:

```json
[ {"id": "gate_key", "kind": "key",  "x": 12.0, "y": 40.0,
   "state": {}},
  {"id": "north_gate_door", "kind": "door", "x": 15.5, "y": 30.5,
   "state": {"locked": true}},
  {"id": "guild_vault", "kind": "heavy_vault", "x": 45.0, "y": 45.0,
   "state": {"locked": true, "cosigners_required": 2}} ]
```

* `kind` must be a kind the tick's `USE_RULES` knows (`key`, `door`,
  `relic`, `heavy_vault`, `ledger`, …) or the entity is scenery with an
  inventory slot — carryable but inert under `use`.
* `state` is a JSON dict, wire-truncated at 64 KB — keep it terse.
* `owner_id` starts `null` (in-world). To pre-place an item in a
  character's pocket, set `owner_id` to their **server id**; carry-pass
  slaves its position from tick one.
* Positions must be on **clear** navgrid cells (check against
  `plaza.json`: not inside a wall rect) — the same rule the Director's
  relic spawner obeys.
* Ids pass the §0.3 compaction pre-flight (the entity plane shares the
  8-byte namespace).

Load path: the engine's entity spawn flag (see `tick_engine.py --help`,
`--entities-file`); mount the JSON beside `plaza.json`.

---

## Phase 2 — The Cloud Shoot (RunPod RTX 4090)

> **⚠ GAP 2-G1 — THE 24 GB REALITY.** The repo's reference composes
> assume 4 GPUs (RunPod A-series) or a GB300. A single 4090 has 24 GB
> for *everything*. The profile that fits: **quantized Qwen3-8B**
> (FP8/AWQ, ~10 GB) + bge-m3 (~2 GB) on the same device,
> `--mem-fraction-static 0.55`, and **the media profile OFF** — F5-TTS
> is 3–4 GB of VRAM for voices that never reach the bundle (see G2-b).
> Every service pins `device_ids: ["0"]` (edit the compose or use the
> DGX compose as the single-GPU template).

> **⚠ GAP 2-G2(b) — VOICES DON'T BAKE.** The bundle is `world.db` +
> `session.usda` + `entities.json`. **No audio.** Running TTS during a
> bake shoot burns VRAM and tokens for sound that evaporates. Skip the
> media profile for shoots. (If the game must have voices, that is a
> future workstream: LiveKit egress recording per track, aligned to
> ticks — budget it separately, don't pay for it accidentally.)

> **⚠ GAP 2-G3 — LIVEKIT IS NOT "MEDIA".** The original compose parks
> the LiveKit SFU behind the `media` profile — but the SFU carries the
> **data planes**, and the recorder and exporter are participants. A
> shoot with media off and no SFU records nothing. Start LiveKit
> explicitly: `docker compose up -d livekit` (or move it out of the
> profile in your compose copy). This is the "fail-open absence looks
> like health" scar wearing a new hat: the engine would run perfectly
> and the recorder would sit in an empty room.

**2.1 — Pod setup** (RunPod: RTX 4090, ≥ 60 GB **network volume**
mounted at `/workspace` — the volume persists across pods; model pulls
happen once, ever):

```bash
git clone <your-repo> && cd panopticon/deploy
./bootstrap.sh                      # first pod ever: pulls models (~20 min)
./bootstrap.sh --skip-models        # every later pod: seconds
echo "PANOPTICON_MODEL=<quantized-qwen3-8b-repo>" >> .env
```

**2.2 — Ignition sequence** (order is law):

```bash
# 1. infrastructure + SFU (NOT the orchestrator yet)
docker compose -f docker-compose-runpod.yml up -d \
    sglang embeddings qdrant neo4j livekit
docker compose -f docker-compose-runpod.yml ps     # wait: every one healthy

# 2. THE LAW: profile the silicon. A quantized model on a 4090 has ITS
#    OWN knee; the crucible's 33 is a different machine's memory.
python3 ../profile_silicon.py --sglang-url http://localhost:8000 \
    --min-knee 10 --report /workspace/profile/report.json
#    exit 3 → UNSERVABLE → change quant/model; do not proceed.
#    exit 0 → apply the printed aimd_max_limit to the orchestrator config.

# 3. seed the lore (Phase 1.2) and VERIFY the Qdrant scroll.

# 4. start the recorder BEFORE the engine — frame zero is part of history:
mkdir -p /workspace/shoots
nohup python3 glasshouse/usd_observer.py \
    --livekit-url ws://localhost:7880 \
    --livekit-api-key $LIVEKIT_API_KEY \
    --livekit-api-secret $LIVEKIT_API_SECRET \
    --stage /workspace/shoots/shoot01.usdc \
    --record /workspace/shoots/shoot01.usdc \
    --map ../deploy/maps/plaza.json \
    --save-hz 0.2 \
    > /workspace/shoots/shoot01.log 2>&1 &
echo $! > /workspace/shoots/observer.pid           # the exporter needs this

# 5. ignite the heartbeat:
docker compose -f docker-compose-runpod.yml up -d orchestrator
docker compose logs -f orchestrator                # 20.0 Hz, overrun 0.0
```

> **⚠ GAP 2-G2 — THE O(n²) SAVE TRAP (the other big one).** In record
> mode, `stage.Save()` rewrites the **entire** stage — which grows every
> tick. At the live default `--save-hz 10`, a long shoot spends more and
> more of each second re-serializing an ever-larger file until saves
> outrun the save interval and the observer's sync loop starves: an
> observer-side stall (the engine, decoupled, never notices — but your
> recording gaps). Two mitigations, both mandatory above: **(a)**
> `--save-hz 0.2` for record shoots — the record is timeSamples in
> memory; frequent saving is a live-view feature you don't need while
> recording (the SIGINT flush writes everything); **(b)** a `.usdc`
> stage path — binary crate, ~10× smaller and far faster to write than
> `.usda` ASCII. And the structural mitigation: **keep shoots short.**
> 15 min ≈ 18 000 ticks × 51 prims ≈ a few hundred MB of crate —
> comfortable. A 4-hour epic is a different architecture (chunked
> stages); don't improvise it on a billed pod.

**2.3 — During the shoot.** Watch Grafana (`--profile obs` if desired) or
the log line telemetry: `tick_max_overrun_ms` ≈ 0, `admission_violations`
= 0, AIMD breathing under the profiled ceiling, and the recorder's
`frames=` counter climbing in `shoot01.log`. Inject Oracle events, let
the Director rotate weather — this is the show. The observer and the
engine never contend: SFU fan-out, separate processes, the recorder's
stall cannot touch the tick (proven in Phase 6's decoupling suite).

---

## Phase 3 — The Bake & Tear-Down

**SEQUENCE LAW: bake against the LIVING stack.** The exporter needs
Neo4j answering read sessions and — critically — **the SFU still up**:
entity capture works by joining as a late joiner and waiting for the
reliable plane's 10 s keyframe, which only exists while the engine is
publishing. The order is: *recorder flushed → bake → verify → download →
verify again → then and only then, tear down.* Killing the stack first
strands the entity snapshot.

```bash
# 1. the bake (flushes the observer itself via SIGINT + quiescence-wait):
python3 glasshouse/local_exporter.py \
    --out /workspace/bundles/shoot01 \
    --neo4j-uri bolt://localhost:7687 --neo4j-password $NEO4J_PASSWORD \
    --livekit-url ws://localhost:7880 \
    --livekit-api-key $LIVEKIT_API_KEY \
    --livekit-api-secret $LIVEKIT_API_SECRET \
    --usd-stage /workspace/shoots/shoot01.usdc \
    --usd-observer-pid $(cat /workspace/shoots/observer.pid)
# The exporter: SIGINTs the recorder, waits for file quiescence, reopens
# and validates the stage; exports the graph in READ-mode sessions
# (the engine may keep ticking — zero disruption is mechanical); captures
# the entity keyframe as one more subscribe-only participant; writes
# manifest.json with SHA-256 per artifact. Wire-id compaction is NOT
# performed here — the bundle carries server ids; the Codex builds the
# compaction bridge at load (PanopticonCodex.BuildWireBridge), which is
# why the §0.3 pre-flight matters: a collision detected on the player's
# machine is a collision you shipped.

# 2. on-pod verification (the bundle fails closed — so prove it passes):
python3 - <<'EOF'
import hashlib, json, pathlib
b = pathlib.Path("/workspace/bundles/shoot01")
man = json.loads((b/"manifest.json").read_text())
for name, meta in man["artifacts"].items():
    h = hashlib.sha256((b/name).read_bytes()).hexdigest()
    assert h == meta["sha256"], f"CORRUPT ON POD: {name}"
print("bundle verified on pod:", man["graph_counts"],
      f"end_tick={man['stage']['end_time_code']:.0f}",
      f"entities={man['entity_count']}")
EOF

# 3. download (runpodctl / rclone / scp), then RE-VERIFY LOCALLY with the
#    same loop — the network is part of the chain of custody. Keep the
#    manifest hashes with the bundle forever; the game re-checks them.

# 4. multiple shoots? loop Phases 2.2(4)→3.3 with new shoot names —
#    the graph ACCUMULATES across shoots on the same volume (memories
#    consolidate across sessions; that is a feature: later shoots have
#    deeper souls). Each bundle snapshots the graph as of its bake.

# 5. TEAR-DOWN — the billing step, in order:
docker compose -f docker-compose-runpod.yml down
# RunPod console: TERMINATE the pod (a *stopped* pod still bills storage
# for its container disk). The network volume persists (models, graph,
# snapshots) and bills pennies; that is the warm-start for next session.
# BUDGET TRAP: never terminate before local re-verification (step 3) —
# the pod's copy of a corrupt download is the only good copy in existence.
```

---

## Phase 4 — Standalone UE5 Integration (zero live LLM compute)

**4.1 — Project setup.**
* `.uproject` plugins: enable **SQLiteCore** and the **USD Importer**
  (provides UnrealUSDWrapper for runtime stage reading).
* `Glasshouse.Build.cs`:
  ```csharp
  PublicDependencyModuleNames.AddRange(new string[] {
      "Core", "CoreUObject", "Engine",
      "SQLiteCore",                       // UPanopticonCodex
      "UnrealUSDWrapper", "USDClasses"    // FBakedPlaybackSource
  });
  ```
* Source files in the module: `MagnusObserver.{h,cpp}`,
  `MotionController.{h,cpp}`, `LocalPlayback.h` (+ your
  `FBakedPlaybackSource` impl), `PanopticonCodex.{h,cpp}`.
* Bundle location: ship under `<Game>/Content/Bundles/shoot01/` (cooked
  as non-asset files) or accept `-PanopticonBundle=<dir>` for dev.

**4.2 — Boot order in `AMagnusObserver::BeginPlay`:**
```cpp
FString BundleDir;
const bool bBaked = FParse::Value(FCommandLine::Get(),
                                  TEXT("PanopticonBundle="), BundleDir)
                    || ResolveShippedBundle(BundleDir);
if (bBaked)
{
    auto Src = MakeUnique<FBakedPlaybackSource>();
    if (!Src->LoadBundle(BundleDir))      // manifest SHA-256s verified —
    {                                     // the bundle FAILS CLOSED
        ShowCorruptBundleScreen(BundleDir);
        return;
    }
    Ingress = MoveTemp(Src);
    GetGameInstance()->GetSubsystem<UPanopticonCodex>()
        ->OpenBundle(BundleDir);          // read-only; refuses non-'PANO'
    SpawnEntitiesFromJson(BundleDir / "entities.json");  // final truth
}
else { Ingress = MakeUnique<FLiveKitIngress>(/* live config */); }
```
Everything downstream — `EvalHermite`, `UGlasshouseMotionController`
(run `motion_sidecar.py --model ...` locally, or ship without it: the
breaker degrades pawns to capsule-glide, fail-open as always), Tier 1
plaza geometry — is byte-identical between live show and boxed game.

**4.3 — Pawn-click → Codex UI.**
1. Player controller: cursor line-trace on click → `APanopticonPawn` →
   its `WireId` (the same 8-byte id the channel map keys on).
2. Open the codex widget; call in order:
   * `Codex->GetBeliefs(WireId)` → conviction list, sized by Importance.
   * `Codex->GetRelations(WireId)` → web panel; each row shows Affinity
     and the LLM-authored `LastReason` sentence; row click →
     re-open codex on `OtherWireId` (pre-computed — the web navigates
     itself).
   * `Codex->GetLifeStory(WireId)` → chronological timeline;
     `bArchived == true` rendered faded; a faded entry's
     `ConsolidatedInto` links upward to the conviction it became.
   * Conviction click → `Codex->GetLineage(MemoryId)` → the raw, faded
     afternoons underneath it.
3. `Codex->IsOpen() == false` → hide the codex affordance entirely
   (live mode, or a refused database). Never show empty lore.
4. Playback transport (play/pause/scrub) binds to
   `FBakedPlaybackSource::SetState / SetPlaybackTime`; a scrub reseeds
   channels like a live late-join and Tier 2 blends back in ≈300 ms.

**Ship-readiness checklist:** bundle hashes verify on the target machine
before packaging · `-PanopticonBundle` boot shows pawns walking the
recorded session · scrub to end-tick and back · click three pawns and one
vault · codex refuses a byte-flipped `world.db` (test it deliberately —
fail-closed is only real if you've seen it fail).

---

## 5 — The Cost Model (why this architecture is cheap)

LLM compute is spent **once**, during the shoot, at 4090 rates; every
player replay costs zero inference forever. The expensive artifact is the
*graph* — and it persists on the network volume across shoots, so each
session's consolidation compounds: characters get deeper while the
per-shoot bill stays flat. Budget levers, strongest first: shoot length
(G2), media profile off (G2-b), quantized model + profiled
`aimd_max_limit` (no backoff-storm token waste), warm volume
(`--skip-models`), terminate-not-stop.

## 6 — The Gap Ledger (found in this review, corrected above)

| # | Gap | Consequence if unfixed | Fix |
|---|---|---|---|
| 1-G1 | Neo4j-only memory seeding | Lore invisible: retrieval is vector-first; agents never recall any of it | Seed via `MemoryService.store_memory` (dual-write); verify Qdrant scroll pre-ignition |
| 2-G1 | 4-GPU compose on a 24 GB card | OOM at ignition or mid-storm | Quantized model, shared device 0, mem-fraction 0.55, media off |
| 2-G2 | `Save()` rewrites the whole growing stage at 10 Hz | Recorder starves late in long shoots; recording gaps | `--save-hz 0.2`, `.usdc` crate, shoots ≤ 15 min |
| 2-G2b | TTS burning VRAM/tokens for un-baked audio | Money spent on sound that evaporates | Media profile off for bake shoots |
| 2-G3 | SFU parked behind the `media` profile | Engine runs perfectly; recorder sits in an empty room (absence looks like health) | `up -d livekit` explicitly in ignition |
| 3-SL | Tear-down before bake | Entity keyframe unrecoverable; graph gone if volume-less | Sequence law: flush → bake → verify → download → re-verify → terminate |

*The heartbeat never bends. The bundle never lies. The bill never
surprises you — because every trap above was sprung on paper first.*
